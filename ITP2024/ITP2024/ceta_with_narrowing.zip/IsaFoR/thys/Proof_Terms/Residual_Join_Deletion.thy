(*
Author:  Christina Kohl <christina.kohl@uibk.ac.at> (2022)
License: LGPL (see file COPYING.LESSER)
*)
theory Residual_Join_Deletion
imports
  Proof_Terms              
begin

text \<open>Auxiliary lemmas in preparation of termination simp rule.\<close>
lemma match_vars_term_size:
  assumes "match s t = Some \<sigma>"
    and "x \<in> vars_term t"
  shows "size (\<sigma> x) \<le> size s"
  using assms vars_term_size by (metis match_matches) 

lemma [termination_simp]: 
  assumes "match (Fun f ss) (to_pterm l) = Some \<sigma>"
    and *: "(s, t) \<in> set (zip (map \<sigma> (var l)) ts)"
  shows "size s \<le> Suc (size_list size ss)"
proof - 
  from * have "s \<in> set (map \<sigma> (var l))" by (blast elim: in_set_zipE)
  then obtain x where [simp]: "s = \<sigma> x"
    and x: "x \<in> vars_term (to_pterm l)" by (induct l) auto
  from match_vars_term_size [OF assms(1)  x]
    show ?thesis by simp
  qed

(*Added this myself because we allow variable left-hand sides of rewrite rules at this point.
 Then Var x / \<alpha> and \<alpha> / Var x are also possible when evaluating residuals,
 which might be interesting when we want to introduce the error rule.*)
lemma [termination_simp]:
  assumes "match (Var x) (to_pterm l) = Some \<sigma>"
    and "(a, b) \<in> set (zip (map \<sigma> (var l)) ts)"
  shows "size a = 1"
proof-
  from assms(1) have *:"(to_pterm l) \<cdot> \<sigma> = Var x" by (simp add: match_matches) 
  then obtain y where y:"l = Var y" by (metis subst_apply_eq_Var term.distinct(1) to_pterm.elims) 
  with * have **:"\<sigma> y = Var x" by simp 
  from y have "var l = [y]" by (simp add: vars_term_list.simps(1))
  with assms(2) y have "a = Var x" by (simp add: "**" in_set_zip) 
  then show ?thesis by simp
qed

section\<open>Residuals\<close>
fun residual :: "('f, 'v) pterm \<Rightarrow> ('f, 'v) pterm \<Rightarrow> ('f, 'v) pterm option" (infixr "re" 70)
  where
  "Var x re Var y =
    (if x = y then Some (Var x) else None)"
| "Pfun f As re Pfun g Bs =  
    (if (f = g \<and> length As = length Bs) then
      (case those (map2 residual As Bs) of
        Some xs \<Rightarrow> Some (Pfun f xs)
      | None \<Rightarrow> None)
    else None)"
| "Prule \<alpha> As re Prule \<beta> Bs =
    (if \<alpha> = \<beta> then 
      (case those (map2 residual As Bs) of
        Some xs \<Rightarrow> Some ((to_pterm (rhs \<alpha>)) \<cdot> \<langle>xs\<rangle>\<^sub>\<alpha>)
      | None \<Rightarrow> None)
    else None)"
| "Prule \<alpha> As re B =
    (case match B (to_pterm (lhs \<alpha>)) of
      None \<Rightarrow> None
    | Some \<sigma> \<Rightarrow>
      (case those (map2 residual As (map \<sigma> (var_rule \<alpha>))) of
        Some xs \<Rightarrow> Some (Prule \<alpha> xs)
      | None \<Rightarrow> None))"
| "A re Prule \<alpha> Bs =
    (case match A (to_pterm (lhs \<alpha>)) of
      None \<Rightarrow> None
    | Some \<sigma> \<Rightarrow>
      (case those (map2 residual (map \<sigma> (var_rule \<alpha>)) Bs) of
        Some xs \<Rightarrow> Some ((to_pterm (rhs \<alpha>)) \<cdot> \<langle>xs\<rangle>\<^sub>\<alpha>)
      | None \<Rightarrow> None))"
| "A re B = None"


text\<open>Since the interesting proofs about residuals always follow the same pattern of induction on the 
definition, we introduce the following 6 lemmas corresponding to the step cases.\<close>
lemma residual_fun_fun:
  assumes "(Pfun f As) re (Pfun g Bs) = Some C"
  shows "f = g \<and> length As = length Bs \<and> 
        (\<exists>Cs. C = Pfun f Cs \<and> 
        length Cs = length As \<and>
        (\<forall>i < length As. As!i re Bs!i = Some (Cs!i)))" 
proof-
  have *:"f = g \<and> length As = length Bs" 
    using assms residual.simps(2) by (metis option.simps(3))
  then obtain Cs where Cs:"those (map2 (re) As Bs) = Some Cs" 
    using assms residual.simps(2) option.simps(3) option.simps(4) by fastforce 
  hence "\<forall>i < length As. As!i re Bs!i = Some (Cs!i)" 
    using * those_some2 by fastforce
  with * Cs assms(1) show ?thesis
    using length_those by fastforce
qed

lemma residual_rule_rule:
  assumes "(Prule \<alpha> As) re (Prule \<beta> Bs) = Some C" 
          "(Prule \<alpha> As) \<in> wf_pterm R" 
          "(Prule \<beta> Bs) \<in> wf_pterm S"
  shows "\<alpha> = \<beta> \<and> length As = length Bs \<and> 
        (\<exists>Cs. C = to_pterm (rhs \<alpha>) \<cdot> \<langle>Cs\<rangle>\<^sub>\<alpha> \<and>
        length Cs = length As \<and> 
        (\<forall>i < length As. As!i re Bs!i = Some (Cs!i)))"
proof-
  have "\<alpha> = \<beta>" 
    using assms(1) residual.simps(3) by (metis option.simps(3))
  with assms(2,3) have l: "length As = length Bs"
    using length_args_well_Prule by blast
  from \<open>\<alpha> = \<beta>\<close> obtain Cs where Cs:"those (map2 (re) As Bs) = Some Cs" 
    using assms by fastforce 
  hence "\<forall>i < length As. As!i re Bs!i = Some (Cs!i)" 
    using l those_some2 by fastforce
  with \<open>\<alpha> = \<beta>\<close> l Cs assms(1) show ?thesis 
    using length_those by fastforce
qed

lemma residual_rule_var:
  assumes "(Prule \<alpha> As) re (Var x) = Some C" 
          "(Prule \<alpha> As) \<in> wf_pterm R" 
  shows "\<exists>\<sigma>. match (Var x) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and> 
        (\<exists>Cs. C = Prule \<alpha> Cs \<and> 
        length Cs = length As \<and> 
        (\<forall>i < length As. As!i re (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i)))" 
proof-
  from assms(2) have l:"length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce 
  obtain \<sigma> where \<sigma>:"match (Var x) (to_pterm (lhs \<alpha>)) = Some \<sigma>" 
    using assms(1) by fastforce
  then obtain Cs where Cs:"those (map2 residual As (map \<sigma> (var_rule \<alpha>))) = Some Cs"  
    using assms(1) by fastforce
  with l have l2:"length Cs = length As" 
    using length_those by fastforce 
  from Cs have "\<forall>i < length As. As!i re (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i)" 
    using l those_some2 by fastforce 
  with \<sigma> Cs assms(1) l2 show ?thesis by simp
qed

lemma residual_rule_fun:
  assumes "(Prule \<alpha> As) re (Pfun f Bs) = Some C" 
          "(Prule \<alpha> As) \<in> wf_pterm R" 
  shows "\<exists>\<sigma>. match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and> 
        (\<exists>Cs. C = Prule \<alpha> Cs \<and> 
        length Cs = length As \<and> 
        (\<forall>i < length As. As!i re (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i)))"
proof-
  from assms(2) have l:"length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce 
  obtain \<sigma> where \<sigma>:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma>" 
    using assms(1) by fastforce
  then obtain Cs where Cs:"those (map2 residual As (map \<sigma> (var_rule \<alpha>))) = Some Cs"  
    using assms(1) by fastforce
  with l have l2:"length Cs = length As" 
    using length_those by fastforce
  from Cs have "\<forall>i < length As. As!i re (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i)" 
    using l those_some2 by fastforce 
  with \<sigma> Cs assms(1) l2 show ?thesis by auto
qed

lemma residual_var_rule:
  assumes "(Var x) re (Prule \<alpha> As) = Some C" 
          "(Prule \<alpha> As) \<in> wf_pterm R" 
  shows "\<exists>\<sigma>. match (Var x) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and> 
        (\<exists>Cs. C = (to_pterm (rhs \<alpha>)) \<cdot> \<langle>Cs\<rangle>\<^sub>\<alpha> \<and> 
        length Cs = length As \<and> 
        (\<forall>i < length As. (\<sigma> (var_rule \<alpha> ! i) re As!i) = Some (Cs!i)))"
proof-
  from assms(2) have l:"length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce 
  obtain \<sigma> where \<sigma>:"match (Var x) (to_pterm (lhs \<alpha>)) = Some \<sigma>" 
    using assms(1) by fastforce
  then obtain Cs where Cs:"those (map2 residual (map \<sigma> (var_rule \<alpha>)) As) = Some Cs"  
    using assms(1) by fastforce
  with l have l2:"length Cs = length As" 
    using length_those by fastforce 
  from Cs have "\<forall>i < length As. (\<sigma> (var_rule \<alpha> ! i)) re As!i = Some (Cs!i)" 
    using l those_some2 by fastforce 
  with \<sigma> Cs assms(1) l2 show ?thesis by auto
qed

lemma residual_fun_rule:
  assumes "(Pfun f Bs) re (Prule \<alpha> As) = Some C" 
          "(Prule \<alpha> As) \<in> wf_pterm R" 
  shows "\<exists>\<sigma>. match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and> 
        (\<exists>Cs. C = (to_pterm (rhs \<alpha>)) \<cdot> \<langle>Cs\<rangle>\<^sub>\<alpha> \<and> 
        length Cs = length As \<and> 
        (\<forall>i < length As. (\<sigma> (var_rule \<alpha> ! i)) re As!i = Some (Cs!i)))"
proof-
  from assms(2) have l:"length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce 
  obtain \<sigma> where \<sigma>:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma>" 
    using assms(1) by fastforce
  then obtain Cs where Cs:"those (map2 residual (map \<sigma> (var_rule \<alpha>)) As) = Some Cs"  
    using assms(1) by fastforce
  with l have l2:"length Cs = length As" 
    using length_those by fastforce 
  with Cs have "\<forall>i < length As. (\<sigma> (var_rule \<alpha> ! i)) re As!i = Some (Cs!i)" 
    using l those_some2 by fastforce 
  with \<sigma> Cs assms(1) l2 show ?thesis by auto
qed


(* t / A = tgt(A) *)
lemma res_empty1:
  assumes "is_empty_step t" "co_initial A t" "A \<in> wf_pterm R"
  shows "t re A = Some (to_pterm (target A))"
proof - 
  from assms(1,2) have "t = to_pterm (source A)"
    by (simp add: empty_coinitial)
  then show ?thesis using assms(3) proof (induction A arbitrary: t)
    case (Var x)
    then show ?case by simp
  next
    case (Pfun f As)
    let ?ts = "(map (to_pterm \<circ> source) As)"
    from Pfun(3) have "\<forall>a \<in> set As. a \<in> wf_pterm R" by blast 
    with Pfun(1) have "those (map2 residual ?ts As) = Some (map (to_pterm \<circ> target) As)" by (simp add:those_some)
    then show ?case unfolding Pfun(2) by simp
  next
    case (Prule \<alpha> As)
    let ?ts = "(map (to_pterm \<circ> source) As)"
    from Prule(3) have l:"length ?ts = length (var_rule \<alpha>)" using wf_pterm.simps by fastforce 
    moreover from Prule(3) have well:"\<forall>a \<in> set As. a \<in> wf_pterm R" by blast 
    from Prule(1) have args:"those (map2 residual ?ts As) = Some (map (to_pterm \<circ> target) As)" using well by (simp add:those_some)
    from Prule(2) have t:"t = (to_pterm (lhs \<alpha>)) \<cdot> \<langle>?ts\<rangle>\<^sub>\<alpha>" by (simp add: to_pterm_subst) 
    then obtain \<sigma> where \<sigma>:
      "match t (to_pterm (lhs \<alpha>)) = Some \<sigma>" 
      "(\<forall>x\<in> set (var_rule \<alpha>). (\<langle>?ts\<rangle>\<^sub>\<alpha>) x = \<sigma> x)"
      using lhs_subst_trivial by blast 
    from \<sigma>(2) l have ts:"map \<sigma> (var_rule \<alpha>) = ?ts" by (smt apply_lhs_subst_var_rule map_eq_conv) 
    from Prule(1) have "those (map2 residual ?ts As) = Some (map (to_pterm \<circ> target) As)" using well by (simp add:those_some) 
    with ts have args:"those (map2 residual (map \<sigma> (var_rule \<alpha>)) As) = Some (map (to_pterm \<circ> target) As)" by simp
    show ?case proof (cases t rule:source.cases)
      case (1 x)
      then show ?thesis using args \<sigma>(1) by (simp add: to_pterm_subst) 
    next
      case (2 f As)
      then show ?thesis using args \<sigma>(1) by (simp add: to_pterm_subst) 
    next
      case (3 \<alpha> As)
      then show ?thesis using Prule(2) by (metis is_empty_step.simps(3) to_pterm_empty)
    qed
  qed
qed

(* A / t = A *)
lemma res_empty2:
  assumes "A \<in> wf_pterm R"
  shows "A re (to_pterm (source A)) = Some A"
using assms proof (induction A)
  case (2 As f)
  then have "those (map2 residual As (map (to_pterm \<circ> source) As)) = Some As" by (simp add:those_some) 
  then show ?case by simp
next
  case (3 \<alpha> As)
  then have \<sigma>: "match (to_pterm (lhs \<alpha> \<cdot> \<langle>map source As\<rangle>\<^sub>\<alpha>)) (to_pterm (lhs \<alpha>)) = Some (\<langle>map (to_pterm \<circ> source) As\<rangle>\<^sub>\<alpha>)"
    by (metis (no_types, lifting) fun_mk_subst lhs_subst_trivial map_map to_pterm.simps(1) to_pterm_subst) 
  from 3 have "those (map2 residual As (map (to_pterm \<circ> source) As)) = Some As" 
    by (simp add:those_some) 
  then have args:"those (map2 residual As (map (\<langle>map (to_pterm \<circ> source) As\<rangle>\<^sub>\<alpha>) (var_rule \<alpha>))) = Some As"
    by (metis "3.hyps"(2) apply_lhs_subst_var_rule length_map) 
  show ?case proof(cases "source (Prule \<alpha> As)")
    case (Var x)
    then show ?thesis 
      using \<sigma> residual.simps(4)[of \<alpha> As x] args by auto
  next
    case (Fun f ts)
    then show ?thesis 
      using \<sigma> residual.simps(5)[of \<alpha> As f] args by auto
  qed
qed simp

(* A / A = tgt(A) *)
lemma res_same: "A re A = Some (to_pterm (target A))"
proof(induction A)
case (Var x)
then show ?case by simp
next
  case (Pfun f As)
  then have "list_all (\<lambda>x. x \<noteq> None) (map2 residual As As)" by (simp add: list_all_length)
  then obtain xs where xs:"those (map2 residual As As) = Some xs" using those_not_none_xs by fastforce
  then have l:"length As = length xs" using length_those by fastforce
  from xs have IH:"i < length As \<Longrightarrow> xs!i = to_pterm (target (As!i))" for i using Pfun those_some2 by force
  from IH l have "map (to_pterm\<circ>target) As = xs" by (simp add: map_nth_eq_conv)
  then have "to_pterm (target (Pfun f As)) = Pfun f xs" by simp 
  then show ?case using xs by simp
next
  case (Prule \<alpha> As)
  then have "list_all (\<lambda>x. x \<noteq> None) (map2 residual As As)" by (simp add: list_all_length)
  then obtain xs where xs:"those (map2 residual As As) = Some xs" using those_not_none_xs by fastforce
  then have l:"length As = length xs" using length_those by fastforce
  from xs have IH:"i < length As \<Longrightarrow> xs!i = to_pterm (target (As!i))" for i using Prule those_some2 by force
  from IH l have *:"map (to_pterm\<circ>target) As = xs" by (simp add: map_nth_eq_conv)
  have "to_pterm (target (Prule \<alpha> As)) = to_pterm (rhs \<alpha> \<cdot> \<langle>map target As\<rangle>\<^sub>\<alpha>)" by simp
  also have "... = (to_pterm (rhs \<alpha>)) \<cdot> (to_pterm \<circ> \<langle>map target As\<rangle>\<^sub>\<alpha>)" by (simp add: to_pterm_subst) 
  also have "... = (to_pterm (rhs \<alpha>)) \<cdot> \<langle>xs\<rangle>\<^sub>\<alpha>" using * by simp 
  finally show ?case using xs by simp
qed


lemma residual_src_tgt: 
  assumes "A re B = Some C" "A \<in> wf_pterm R" "B \<in> wf_pterm S"
  shows "source C = target B"
  using assms proof(induction A B arbitrary: C rule: residual.induct)
  case (1 x y)
  then show ?case
    by (metis option.distinct(1) option.sel residual.simps(1) source.simps(1) target.simps(1)) 
next
  case (2 f As g Bs)
  then obtain Cs where *:"f = g \<and> length As = length Bs \<and>
      C = Pfun f Cs \<and> length Cs = length As \<and> 
      (\<forall>i<length As. As ! i re Bs ! i = Some (Cs ! i))" 
    by (meson residual_fun_fun) 
  then have "length (zip As Bs) = length As" by simp 
  moreover from 2(3) have "\<forall>a \<in> set As. a \<in> wf_pterm R" by blast
  moreover from 2(4) have "\<forall>b \<in> set Bs. b \<in> wf_pterm S" by blast
  ultimately have "\<forall>i < length As. source (Cs!i) = target (Bs!i)" 
    using * 2 by (metis nth_mem nth_zip) 
  with * show ?case by (simp add: nth_map_conv)
next
  case (3 \<alpha> As \<beta> Bs)
  then obtain Cs where *:"\<alpha> = \<beta> \<and> length As = length Bs \<and>
      C = to_pterm (rhs \<alpha>) \<cdot> \<langle>Cs\<rangle>\<^sub>\<alpha> \<and> length Cs = length As \<and> 
      (\<forall>i<length As. As ! i re Bs ! i = Some (Cs ! i))" 
    by (meson residual_rule_rule) 
  then have "length (zip As Bs) = length As" by simp 
  moreover from 3(3) have "\<forall>a \<in> set As. a \<in> wf_pterm R" by blast
  moreover from 3(4) have "\<forall>b \<in> set Bs. b \<in> wf_pterm S" by blast
  ultimately have IH:"\<forall>i < length As. source (Cs!i) = target (Bs!i)" 
    using * 3 by (metis nth_mem nth_zip) 
  from * have "source C = (rhs \<beta>) \<cdot> \<langle>map source Cs\<rangle>\<^sub>\<beta>" 
     by (simp add: source_apply_subst)
  also have "... = (rhs \<beta>) \<cdot> \<langle>map target Bs\<rangle>\<^sub>\<beta>" 
    using * IH by (metis nth_map_conv)
  finally show ?case by simp
next
  case ("4_1" \<alpha> As v)
  then obtain Cs \<sigma> where *:"match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and>
        C = Prule \<alpha> Cs \<and> length Cs = length As \<and> 
        (\<forall>i<length As. As ! i re \<sigma> (var_rule \<alpha> ! i) = Some (Cs ! i))"
    by (meson residual_rule_var) 
  then obtain Bs where Bs:"length Bs = length (var_rule \<alpha>) \<and> 
                          Var v = (to_pterm (lhs \<alpha>)) \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha> \<and>
                          (\<forall>x \<in> set (var_rule \<alpha>). \<sigma> x = (\<langle>Bs\<rangle>\<^sub>\<alpha>) x)" 
    using match_lhs_subst by blast 
  from "4_1"(3) have as:"\<forall>a \<in> set As. a \<in> wf_pterm R" by blast
  from "4_1"(3) have l:"length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce 
  with * have well:"\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm S"  
    using "4_1"(4) by (metis match_well_def vars_to_pterm)  
  from l have "length (zip As (map \<sigma> (var_rule \<alpha>))) = length As" by simp   
  with "4_1"(1,3) well * l as have IH:"\<forall>i < length As. source (Cs!i) = target (map (\<langle>Bs\<rangle>\<^sub>\<alpha>) (var_rule \<alpha>) !i)" 
    using Bs by (smt length_map nth_map nth_mem nth_zip)
  from * have "source C = (lhs \<alpha>) \<cdot> \<langle>map source Cs\<rangle>\<^sub>\<alpha>" 
     by (simp add: source_apply_subst)
  also have "... = (lhs \<alpha>) \<cdot> \<langle>map (target \<circ> (\<langle>Bs\<rangle>\<^sub>\<alpha>)) (var_rule \<alpha>)\<rangle>\<^sub>\<alpha>" 
    using * l IH by (smt map_eq_conv' map_map)
  also have "... = (lhs \<alpha>) \<cdot> (target \<circ> (\<langle>Bs\<rangle>\<^sub>\<alpha>))" 
    using Bs by (metis (no_types, lifting) apply_lhs_subst_var_rule fun_mk_subst map_map target.simps(1)) 
  also have "... = target (to_pterm (lhs \<alpha>) \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha>)"
    by (metis target_empty_apply_subst target_to_pterm to_pterm_empty)
  finally show ?case
    using Bs by fastforce 
next
  case ("4_2" \<alpha> As f Bs)
  then obtain Cs \<sigma> where *:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and>
        C = Prule \<alpha> Cs \<and> length Cs = length As \<and> 
        (\<forall>i<length As. As ! i re \<sigma> (var_rule \<alpha> ! i) = Some (Cs ! i))"
    by (meson residual_rule_fun) 
  then obtain Bs' where Bs':"length Bs' = length (var_rule \<alpha>) \<and> 
                          Pfun f Bs = (to_pterm (lhs \<alpha>)) \<cdot> \<langle>Bs'\<rangle>\<^sub>\<alpha> \<and>
                          (\<forall>x \<in> set (var_rule \<alpha>). \<sigma> x = (\<langle>Bs'\<rangle>\<^sub>\<alpha>) x)" 
    using match_lhs_subst by blast 
  from "4_2"(3) have as:"\<forall>a \<in> set As. a \<in> wf_pterm R" by blast
  from "4_2"(3) have l:"length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce 
  with * have well:"\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm S" 
    using "4_2"(4) by (metis match_well_def vars_to_pterm)  
  from l have "length (zip As (map \<sigma> (var_rule \<alpha>))) = length As" by simp   
  with "4_2"(1,3) well * l as have IH:"\<forall>i < length As. source (Cs!i) = target (map (\<langle>Bs'\<rangle>\<^sub>\<alpha>) (var_rule \<alpha>) !i)" 
    using Bs' by (smt length_map nth_map nth_mem nth_zip)
  from * have "source C = (lhs \<alpha>) \<cdot> \<langle>map source Cs\<rangle>\<^sub>\<alpha>" 
     by (simp add: source_apply_subst)
  also have "... = (lhs \<alpha>) \<cdot> \<langle>map (target \<circ> (\<langle>Bs'\<rangle>\<^sub>\<alpha>)) (var_rule \<alpha>)\<rangle>\<^sub>\<alpha>" 
    using * l IH by (smt map_eq_conv' map_map)
  also have "... = (lhs \<alpha>) \<cdot> (target \<circ> (\<langle>Bs'\<rangle>\<^sub>\<alpha>))" 
    using Bs' by (metis (no_types, lifting) apply_lhs_subst_var_rule fun_mk_subst map_map target.simps(1)) 
  also have "... = target (to_pterm (lhs \<alpha>) \<cdot> \<langle>Bs'\<rangle>\<^sub>\<alpha>)"
    by (metis target_empty_apply_subst target_to_pterm to_pterm_empty)
  finally show ?case
    using Bs' by fastforce 
next
  case ("5_1" v \<alpha> As)
  then obtain Cs \<sigma> where *:"match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and>
        C = to_pterm (rhs \<alpha>) \<cdot> \<langle>Cs\<rangle>\<^sub>\<alpha> \<and> length Cs = length As \<and> 
        (\<forall>i<length As. \<sigma> (var_rule \<alpha> ! i) re As ! i  = Some (Cs ! i))"
    by (meson residual_var_rule) 
  from "5_1"(4) have as:"\<forall>a \<in> set As. a \<in> wf_pterm S" by blast
  from "5_1"(4) have l:"length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce 
  with * have well:"\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R" 
    using "5_1"(3) by (metis match_well_def vars_to_pterm)  
  from l have "length (zip (map \<sigma> (var_rule \<alpha>)) As) = length As" by simp   
  with "5_1"(1,4) well * l as have IH:"\<forall>i < length As. source (Cs!i) = target (As!i)" 
    by (smt length_map nth_map nth_mem nth_zip)
  from * have "source C = (rhs \<alpha>) \<cdot> \<langle>map source Cs\<rangle>\<^sub>\<alpha>" 
     by (simp add: source_apply_subst)
  also have "... = (rhs \<alpha>) \<cdot> \<langle>map target As\<rangle>\<^sub>\<alpha>" 
    using * IH by (metis (no_types, lifting) map_eq_conv')
  finally show ?case by simp
next
  case ("5_2" f Bs \<alpha> As)
    then obtain Cs \<sigma> where *:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and>
        C = to_pterm (rhs \<alpha>) \<cdot> \<langle>Cs\<rangle>\<^sub>\<alpha> \<and> length Cs = length As \<and> 
        (\<forall>i<length As. \<sigma> (var_rule \<alpha> ! i) re As ! i  = Some (Cs ! i))"
      by (meson residual_fun_rule) 
  from "5_2"(4) have as:"\<forall>a \<in> set As. a \<in> wf_pterm S" by blast
  from "5_2"(4) have l:"length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce 
  with * have well:"\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R" 
    using "5_2"(3) by (metis match_well_def vars_to_pterm)  
  from l have "length (zip (map \<sigma> (var_rule \<alpha>)) As) = length As" by simp   
  with "5_2"(1,4) well * l as have IH:"\<forall>i < length As. source (Cs!i) = target (As!i)" 
    by (smt length_map nth_map nth_mem nth_zip)
  from * have "source C = (rhs \<alpha>) \<cdot> \<langle>map source Cs\<rangle>\<^sub>\<alpha>" 
     by (simp add: source_apply_subst)
  also have "... = (rhs \<alpha>) \<cdot> \<langle>map target As\<rangle>\<^sub>\<alpha>" 
    using * IH by (metis (no_types, lifting) map_eq_conv')
  finally show ?case by simp
qed simp_all

text\<open>The following two lemmas are used inside the induction proof for tgt-tgt.
This way they can be reused in the symmetric cases of the proof.\<close>
lemma tgt_tgt_rule_var:
  assumes "\<And>\<sigma> a b c d. match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<Longrightarrow>
           (a,b) \<in> set (zip As (map \<sigma> (var_rule \<alpha>))) \<Longrightarrow> 
            a re b = Some c \<Longrightarrow> b re a = Some d \<Longrightarrow> a \<in> wf_pterm R \<Longrightarrow> b \<in> wf_pterm S \<Longrightarrow> 
            target c = target d"
          "Prule \<alpha> As re Var v = Some C"
          "Var v re Prule \<alpha> As = Some D"
          "Prule \<alpha> As \<in> wf_pterm R" 
  shows "target C = target D"
proof-
  from assms(4) have l:"length As = length (var_rule \<alpha>)" 
    using wf_pterm.simps by fastforce 
  from assms(4) have as:"\<forall>a \<in> set As. a \<in> wf_pterm R" by blast
  from assms(2,4) obtain \<sigma> where \<sigma>:"match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma>"
    by (meson residual_rule_var)
  with l have well_def:"\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm S" 
    using match_well_def by (metis vars_to_pterm wf_pterm.intros(1))
  from assms(2,4) \<sigma> obtain Cs where Cs: 
      "C = Prule \<alpha> Cs \<and> length Cs = length As"
      "(\<forall>i<length As. As ! i re \<sigma> (var_rule \<alpha> ! i) = Some (Cs ! i))"
    by (metis option.inject residual_rule_var)
  from assms(3,4) \<sigma> obtain Ds where Ds: 
      "D = to_pterm (rhs \<alpha>) \<cdot> \<langle>Ds\<rangle>\<^sub>\<alpha> \<and> length Ds = length As" 
      "(\<forall>i<length As. \<sigma> (var_rule \<alpha> ! i) re As ! i = Some (Ds ! i))"
    by (metis option.inject residual_var_rule)
  from l have "length As = length (zip As (map \<sigma> (var_rule \<alpha>)))"
    by simp 
  with assms(1,4) \<sigma> l Cs(2) Ds(2) well_def have IH:"\<forall>i < length As. target (Cs!i) = target (Ds!i)" 
    using as by (smt length_map nth_map nth_mem nth_zip)
  from Cs have "target C = (rhs \<alpha>) \<cdot> \<langle>map target Cs\<rangle>\<^sub>\<alpha>" by simp
  moreover from Ds(1) have "target D = (rhs \<alpha>) \<cdot> \<langle>map target Ds\<rangle>\<^sub>\<alpha>" 
    using target_empty_apply_subst to_pterm_empty by (metis fun_mk_subst target.simps(1) target_to_pterm)
  ultimately show ?thesis 
    using IH Cs(1) Ds(1) by (metis nth_map_conv)
qed

lemma tgt_tgt_rule_fun:
  assumes "\<And>\<sigma> a b c d. match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<Longrightarrow>
           (a,b) \<in> set (zip As (map \<sigma> (var_rule \<alpha>))) \<Longrightarrow> 
            a re b = Some c \<Longrightarrow> b re a = Some d \<Longrightarrow> a \<in> wf_pterm R \<Longrightarrow> b \<in> wf_pterm S \<Longrightarrow> 
            target c = target d"
          "Prule \<alpha> As re Pfun f Bs = Some C"
          "Pfun f Bs re Prule \<alpha> As = Some D"
          "Prule \<alpha> As \<in> wf_pterm R" 
          "Pfun f Bs \<in> wf_pterm S"
  shows "target C = target D"
proof-
  from assms(4) have l:"length As = length (var_rule \<alpha>)" 
    using wf_pterm.simps by fastforce 
  from assms(4) have as:"\<forall>a \<in> set As. a \<in> wf_pterm R" by blast
  from assms(2,4) obtain \<sigma> where \<sigma>:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma>"
    by (meson residual_rule_fun)
  with assms(2,5) l have well_def:"\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm S" 
    using match_well_def by (metis vars_to_pterm)
  from assms(2,4) \<sigma> obtain Cs where Cs: 
      "C = Prule \<alpha> Cs \<and> length Cs = length As"
      "(\<forall>i<length As. As ! i re \<sigma> (var_rule \<alpha> ! i) = Some (Cs ! i))"
    by (metis option.inject residual_rule_fun)
  from assms(3,4) \<sigma> obtain Ds where Ds: 
      "D = to_pterm (rhs \<alpha>) \<cdot> \<langle>Ds\<rangle>\<^sub>\<alpha> \<and> length Ds = length As" 
      "(\<forall>i<length As. \<sigma> (var_rule \<alpha> ! i) re As ! i = Some (Ds ! i))"
    by (metis option.inject residual_fun_rule)
  from l have "length As = length (zip As (map \<sigma> (var_rule \<alpha>)))"
    by simp 
  with assms(1,4,5) \<sigma> l Cs(2) Ds(2) well_def have IH:"\<forall>i < length As. target (Cs!i) = target (Ds!i)" 
    using as by (smt length_map nth_map nth_mem nth_zip)
  from Cs have "target C = (rhs \<alpha>) \<cdot> \<langle>map target Cs\<rangle>\<^sub>\<alpha>" by simp
  moreover from Ds(1) have "target D = (rhs \<alpha>) \<cdot> \<langle>map target Ds\<rangle>\<^sub>\<alpha>" 
    using target_empty_apply_subst to_pterm_empty by (metis fun_mk_subst target.simps(1) target_to_pterm)
  ultimately show ?thesis 
    using IH Cs(1) Ds(1) by (metis nth_map_conv)
qed

lemma residual_tgt_tgt:
  assumes "A re B = Some C" "B re A = Some D" "A \<in> wf_pterm R" "B \<in> wf_pterm S"
  shows "target C = target D"
  using assms proof(induction A B arbitrary: C D rule:residual.induct)
  case (1 x y)
  then show ?case by (metis option.sel residual.simps(1)) 
next
  case (2 f As g Bs)
  from 2(4) have as:"\<forall>a \<in> set As. a \<in> wf_pterm R" by blast
  from 2(5) have bs:"\<forall>b \<in> set Bs. b \<in> wf_pterm S" by blast
  let ?l = "length As"
  from 2(2) have *: "f = g \<and> ?l = length Bs" 
    by (meson residual_fun_fun)
  from 2(2) obtain Cs where Cs:
    "C = Pfun f Cs \<and> length Cs = ?l \<and> (\<forall>i < ?l. As ! i re Bs ! i = Some (Cs ! i))" 
    by (meson residual_fun_fun)
  from 2(3) obtain Ds where Ds:
    "D = Pfun g Ds \<and> length Ds = ?l \<and> (\<forall>i < ?l. Bs ! i re As ! i = Some (Ds ! i))" 
    using * by (metis residual_fun_fun)
  from * have "length (zip As Bs) = ?l" by simp 
  with 2(1,4,5) * Cs Ds have "\<forall>i < ?l. target (Cs!i) = target (Ds!i)" 
    using as bs by (metis nth_mem nth_zip)   
  with * Cs Ds show ?case
    by (simp add: map_nth_eq_conv) 
next
  case (3 \<alpha> As \<beta> Bs)
  from 3(4) have as:"\<forall>a \<in> set As. a \<in> wf_pterm R" by blast
  from 3(5) have bs:"\<forall>b \<in> set Bs. b \<in> wf_pterm S" by blast
  let ?l = "length As"
  from 3(2,4,5) have *: "\<alpha> = \<beta> \<and> ?l = length Bs" 
    by (meson residual_rule_rule)
  from 3(2,4,5) obtain Cs where Cs:
    "C = to_pterm (rhs \<alpha>) \<cdot> \<langle>Cs\<rangle>\<^sub>\<alpha> \<and> length Cs = ?l \<and> (\<forall>i < ?l. As ! i re Bs ! i = Some (Cs ! i))" 
    by (meson residual_rule_rule)
  from 3(3,4,5) obtain Ds where Ds:
    "D = to_pterm (rhs \<alpha>) \<cdot> \<langle>Ds\<rangle>\<^sub>\<alpha> \<and> length Ds = ?l \<and> (\<forall>i < ?l. Bs ! i re As ! i = Some (Ds ! i))" 
    using * by (metis residual_rule_rule) 
  from * have "length (zip As Bs) = ?l" by simp 
  with 3(1,4,5) * Cs Ds have IH:"\<forall>i < ?l. target (Cs!i) = target (Ds!i)" 
    using as bs by (metis nth_mem nth_zip) 
  from Cs have "target C = (rhs \<alpha>) \<cdot> \<langle>map target Cs\<rangle>\<^sub>\<alpha>" 
    using target_empty_apply_subst to_pterm_empty by (metis fun_mk_subst target.simps(1) target_to_pterm)
  moreover from Ds have "target D = (rhs \<alpha>) \<cdot> \<langle>map target Ds\<rangle>\<^sub>\<alpha>" 
    using target_empty_apply_subst to_pterm_empty by (metis fun_mk_subst target.simps(1) target_to_pterm)
  ultimately show ?case 
    using IH Cs Ds by (metis nth_map_conv)
next 
  case ("4_1" \<alpha> As v)
  then show ?case using tgt_tgt_rule_var by fastforce
next
  case ("4_2" \<alpha> As f Bs)
  then show ?case using tgt_tgt_rule_fun by fastforce 
next
  case ("5_1" v \<alpha> As)
  from "5_1"(1) have "match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<Longrightarrow>
    (a,b) \<in> set (zip As (map \<sigma> (var_rule \<alpha>))) \<Longrightarrow>
    a re b = Some c \<Longrightarrow> b re a = Some d \<Longrightarrow> a \<in> wf_pterm S \<Longrightarrow> b \<in> wf_pterm R \<Longrightarrow> 
    target c = target d" for \<sigma> a b c d 
    using zip_symm by fastforce 
  with "5_1"(2,3,5) have "target D = target C" using tgt_tgt_rule_var by fastforce 
  then show ?case by simp
next
  case ("5_2" f Bs \<alpha> As)
  from "5_2"(1) have "match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<Longrightarrow>
    (a,b) \<in> set (zip As (map \<sigma> (var_rule \<alpha>))) \<Longrightarrow>
    a re b = Some c \<Longrightarrow> b re a = Some d \<Longrightarrow> a \<in> wf_pterm S \<Longrightarrow> b \<in> wf_pterm R \<Longrightarrow> 
    target c = target d" for \<sigma> a b c d 
    using zip_symm by fastforce 
  with "5_2"(2,3,4,5) have "target D = target C" using tgt_tgt_rule_fun by fastforce 
  then show ?case by simp
qed simp_all

lemma rule_residual_lhs:
  assumes args:"those (map2 (re) As Bs) = Some Cs"
    and is_Fun:"is_Fun (lhs \<alpha>)" and l:"length Bs = length (var_rule \<alpha>)" 
  shows "Prule \<alpha> As re (to_pterm (lhs \<alpha>) \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha>) = Some (Prule \<alpha> Cs)" 
proof-
  from is_Fun obtain f ts where "lhs \<alpha> = Fun f ts"
    by auto 
  then have f:"to_pterm (lhs \<alpha>) \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha> = Pfun f (map (\<lambda>t. t \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha>) (map to_pterm ts))" 
    by simp
  then have match:"match ((to_pterm (lhs \<alpha>)) \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha>) (to_pterm (lhs \<alpha>)) = Some (\<langle>Bs\<rangle>\<^sub>\<alpha>)"
    using lhs_subst_trivial by blast 
  from l have "map (\<langle>Bs\<rangle>\<^sub>\<alpha>) (var_rule \<alpha>) = Bs"
    using apply_lhs_subst_var_rule by blast  
  with args have "those (map2 (re) As (map (\<langle>Bs\<rangle>\<^sub>\<alpha>) (var_rule \<alpha>))) = Some Cs"  
    by presburger
  then show ?thesis 
    using residual.simps(5) match unfolding f by auto 
qed

lemma residual_well_defined: 
  assumes "A \<in> wf_pterm R" "B \<in> wf_pterm S" "A re B = Some C"
  shows "C \<in> wf_pterm R"
  using assms proof(induction A B arbitrary:C rule:residual.induct)
  case (1 x y)
  then show ?case 
    by (metis option.distinct(1) option.sel residual.simps(1))
next
  case (2 f As g Bs)
  then obtain Cs where "f = g \<and> length As = length Bs \<and> 
        C = Pfun f Cs \<and> 
        length Cs = length As \<and> 
        (\<forall>i < length As. As!i re Bs!i = Some (Cs!i))" 
    by (meson residual_fun_fun)
  moreover with 2 have "i < length As \<Longrightarrow> Cs!i \<in> wf_pterm R" for i 
    using fun_well_arg by (metis (no_types, opaque_lifting) fst_conv in_set_zip nth_mem snd_conv) 
  ultimately show ?case
    by (metis in_set_conv_nth wf_pterm.intros(2))
next
  case (3 \<alpha> As \<beta> Bs)
  then obtain Cs where "\<alpha> = \<beta> \<and> length As = length Bs \<and> 
        (C = to_pterm (rhs \<alpha>) \<cdot> \<langle>Cs\<rangle>\<^sub>\<alpha> \<and>
        length Cs = length As \<and> 
        (\<forall>i < length As. As!i re Bs!i = Some (Cs!i)))"
    by (meson residual_rule_rule)
  moreover with 3 have "i < length As \<Longrightarrow> Cs!i \<in> wf_pterm R" for i 
    using fun_well_arg by (metis (no_types, opaque_lifting) fst_conv in_set_zip nth_mem snd_conv) 
  ultimately show ?case 
    by (metis to_pterm_wf_pterm lhs_subst_well_def) 
next
  case ("4_1" \<alpha> As v)
  then obtain Cs \<sigma> where *:"match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and> 
        C = Prule \<alpha> Cs \<and> 
        length Cs = length As \<and>
        (\<forall>i < length As. As!i re (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i))"
    by (meson residual_rule_var)
  from "4_1"(2) have wellA:"\<forall>i < length As. As!i \<in> wf_pterm R"
    by auto
  from "4_1"(2) have l: "length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce  
  then have l2:"length As = length (zip As (map \<sigma> (var_rule \<alpha>)))" 
    by simp
  from l * have "\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm S" 
    using "4_1"(3) by (metis match_well_def vars_to_pterm)
  with "4_1"(1) * wellA l2 have "\<forall>i < length As. Cs!i \<in> wf_pterm R"
    by (smt (z3) l length_map nth_map nth_mem nth_zip)
  with "4_1"(2) * show ?case
    by (smt (verit) Inr_not_Inl in_set_conv_nth term.distinct(1) term.inject(2) wf_pterm.cases wf_pterm.intros(3)) 
next
  case ("4_2" \<alpha> As f Bs)
  then obtain \<sigma> Cs where *:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and> 
        (C = Prule \<alpha> Cs \<and> 
        length Cs = length As \<and>
        (\<forall>i < length As. As!i re (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i)))"
    by (meson residual_rule_fun)
  from "4_2"(2) have wellA:"\<forall>i < length As. As!i \<in> wf_pterm R"
    by auto
  from "4_2"(2) have l: "length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce  
  then have l2:"length As = length (zip As (map \<sigma> (var_rule \<alpha>)))" 
    by simp
  from l * have "\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm S" 
    using "4_2"(3) by (metis match_well_def vars_to_pterm)  
  with "4_2"(1) * wellA l2 have "\<forall>i < length As. Cs!i \<in> wf_pterm R"
    by (smt l length_map nth_map nth_mem nth_zip)
  with "4_2"(2) * show ?case
    by (smt (verit, ccfv_threshold) Inr_not_Inl in_set_conv_nth term.distinct(1) term.inject(2) wf_pterm.cases wf_pterm.intros(3))
next
  case ("5_1" v \<alpha> As)
  then obtain Cs \<sigma> where *:"match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and> 
        C = to_pterm (rhs \<alpha>) \<cdot> \<langle>Cs\<rangle>\<^sub>\<alpha>  \<and> 
        length Cs = length As \<and>
        (\<forall>i < length As. (\<sigma> (var_rule \<alpha> ! i)) re As!i = Some (Cs!i))"
    by (meson residual_var_rule)
  from "5_1"(3) have wellA:"\<forall>i < length As. As!i \<in> wf_pterm S"
    by auto
  from "5_1"(3) have l: "length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce  
  then have l2:"length As = length (zip (map \<sigma> (var_rule \<alpha>)) As)" 
    by simp
  from l * have "\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R" 
    using "5_1"(2) by (metis match_well_def vars_to_pterm)  
  with "5_1"(1) * wellA l2 have "\<forall>i < length As. Cs!i \<in> wf_pterm R"
    by (smt l length_map nth_map nth_mem nth_zip)
  with * show ?case
    by (metis lhs_subst_well_def to_pterm_wf_pterm) 
next
  case ("5_2" f Bs \<alpha> As)
  then obtain Cs \<sigma> where *:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and> 
        C = to_pterm (rhs \<alpha>) \<cdot> \<langle>Cs\<rangle>\<^sub>\<alpha>  \<and> 
        length Cs = length As \<and>
        (\<forall>i < length As. (\<sigma> (var_rule \<alpha> ! i)) re As!i = Some (Cs!i))"
    by (meson residual_fun_rule)
  from "5_2"(3) have wellA:"\<forall>i < length As. As!i \<in> wf_pterm S"
    by auto
  from "5_2"(3) have l: "length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce  
  then have l2:"length As = length (zip (map \<sigma> (var_rule \<alpha>)) As)" 
    by simp
  from l * have "\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R" 
    using "5_2"(2) by (metis match_well_def vars_to_pterm)  
  with "5_2"(1) * wellA l2 have "\<forall>i < length As. Cs!i \<in> wf_pterm R"
    by (smt l length_map nth_map nth_mem nth_zip)
  with * show ?case
    by (metis lhs_subst_well_def to_pterm_wf_pterm) 
qed simp_all

section\<open>Join\<close>
fun join :: "('f, 'v) pterm \<Rightarrow> ('f,'v) pterm \<Rightarrow> ('f,'v) pterm option" (infixr "\<squnion>" 70)
  where
  "Var x \<squnion> Var y =
    (if x = y then Some (Var x) else None)"
| "Pfun f As \<squnion> Pfun g Bs =
    (if (f = g \<and> length As = length Bs) then
      (case those (map2 (\<squnion>) As Bs) of
        Some xs \<Rightarrow> Some (Pfun f xs)
      | None \<Rightarrow> None)
    else None)"
| "Prule \<alpha> As \<squnion> Prule \<beta> Bs =
    (if \<alpha> = \<beta> then
      (case those (map2 (\<squnion>) As Bs) of
        Some xs \<Rightarrow> Some (Prule \<alpha> xs)
      | None \<Rightarrow> None)
    else None)"
| "Prule \<alpha> As \<squnion> B =
    (case match B (to_pterm (lhs \<alpha>)) of
      None \<Rightarrow> None
    | Some \<sigma> \<Rightarrow>
      (case those (map2 (\<squnion>) As (map \<sigma> (var_rule \<alpha>))) of
        Some xs \<Rightarrow> Some (Prule \<alpha> xs)
      | None \<Rightarrow> None))"
| "A \<squnion> Prule \<alpha> Bs =
    (case match A (to_pterm (lhs \<alpha>)) of
      None \<Rightarrow> None
    | Some \<sigma> \<Rightarrow>
      (case those (map2 (\<squnion>) (map \<sigma> (var_rule \<alpha>)) Bs) of
        Some xs \<Rightarrow> Some (Prule \<alpha> xs)
      | None \<Rightarrow> None))"
| "A \<squnion> B = None"

lemma union_sym: "A \<squnion> B = B \<squnion> A"
proof(induct rule:join.induct)
  case (2 f As g Bs)
  then show ?case proof(cases "f = g \<and> length As = length Bs")
    case True
    with 2 have "\<forall>(a,b) \<in> set (zip As Bs). a \<squnion> b = b \<squnion> a"
      by auto
    with True have "(map2 (\<squnion>) As Bs) = (map2 (\<squnion>) Bs As)"
      by (smt case_prod_unfold map_eq_conv' map_fst_zip map_snd_zip nth_mem)
    then show ?thesis using 2 unfolding join.simps
      by auto
  qed auto
next
  case (3 \<alpha> As \<beta> Bs)
  then show ?case proof(cases "\<alpha> = \<beta>")
    case True
    with 3 have *:"\<forall>(a,b) \<in> set (zip As Bs). a \<squnion> b = b \<squnion> a"
      by auto
    have "length (map2 (\<squnion>) As Bs) = length (map2 (\<squnion>) Bs As)"
      by auto
    with * have "(map2 (\<squnion>) As Bs) = (map2 (\<squnion>) Bs As)"
      by (smt fst_conv length_map length_zip map_eq_conv' min_less_iff_conj nth_mem nth_zip prod.case_eq_if snd_conv)
    then show ?thesis using 3 unfolding join.simps
      by auto
  qed auto
next
  case ("4_1" \<alpha> As v)
  then show ?case proof(cases "match (Var v) (to_pterm (lhs \<alpha>)) = None")
    case False
    then obtain \<sigma> where sigma:"match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma>"
      by blast
    with "4_1" have *:"\<forall>(a,b) \<in> set (zip As (map \<sigma> (var_rule \<alpha>))). a \<squnion> b = b \<squnion> a"
      by auto
    have "length (map2 (\<squnion>) As (map \<sigma> (var_rule \<alpha>))) = length (map2 (\<squnion>) (map \<sigma> (var_rule \<alpha>)) As)"
      by auto
    with * have "(map2 (\<squnion>) As (map \<sigma> (var_rule \<alpha>))) = (map2 (\<squnion>) (map \<sigma> (var_rule \<alpha>)) As)"
      by (smt fst_conv length_map length_zip map_eq_conv' min_less_iff_conj nth_mem nth_zip prod.case_eq_if snd_conv)
    then show ?thesis unfolding join.simps sigma
      by simp
  qed simp
next
  case ("4_2" \<alpha> As f Bs)
  then show ?case proof(cases "match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = None")
    case False
    then obtain \<sigma> where sigma:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma>"
      by blast
    with "4_2" have *:"\<forall>(a,b) \<in> set (zip As (map \<sigma> (var_rule \<alpha>))). a \<squnion> b = b \<squnion> a"
      by auto
    have "length (map2 (\<squnion>) As (map \<sigma> (var_rule \<alpha>))) = length (map2 (\<squnion>) (map \<sigma> (var_rule \<alpha>)) As)"
      by auto
    with * have "(map2 (\<squnion>) As (map \<sigma> (var_rule \<alpha>))) = (map2 (\<squnion>) (map \<sigma> (var_rule \<alpha>)) As)"
      by (smt fst_conv length_map length_zip map_eq_conv' min_less_iff_conj nth_mem nth_zip prod.case_eq_if snd_conv)
    then show ?thesis unfolding join.simps sigma
      by simp
  qed simp
next
  case ("5_1" v \<alpha> Bs)
  then show ?case proof(cases "match (Var v) (to_pterm (lhs \<alpha>)) = None")
    case False
    then obtain \<sigma> where sigma:"match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma>"
      by blast
    with "5_1" have *:"\<forall>(a,b) \<in> set (zip (map \<sigma> (var_rule \<alpha>)) Bs). a \<squnion> b = b \<squnion> a"
      by auto
    have "length (map2 (\<squnion>) (map \<sigma> (var_rule \<alpha>)) Bs) = length (map2 (\<squnion>) Bs (map \<sigma> (var_rule \<alpha>)))"
      by auto
    with * have "(map2 (\<squnion>) (map \<sigma> (var_rule \<alpha>)) Bs) = (map2 (\<squnion>) Bs (map \<sigma> (var_rule \<alpha>)))"
      by (smt fst_conv length_map length_zip map_eq_conv' min_less_iff_conj nth_mem nth_zip prod.case_eq_if snd_conv)
    then show ?thesis unfolding join.simps sigma
      by simp
  qed simp
next
  case ("5_2" f As \<alpha> Bs)
  then show ?case proof(cases "match (Pfun f As) (to_pterm (lhs \<alpha>)) = None")
    case False
    then obtain \<sigma> where sigma:"match (Pfun f As) (to_pterm (lhs \<alpha>)) = Some \<sigma>"
      by blast
    with "5_2" have *:"\<forall>(a,b) \<in> set (zip (map \<sigma> (var_rule \<alpha>)) Bs). a \<squnion> b = b \<squnion> a"
      by auto
    have "length (map2 (\<squnion>) (map \<sigma> (var_rule \<alpha>)) Bs) = length (map2 (\<squnion>) Bs (map \<sigma> (var_rule \<alpha>)))"
      by auto
    with * have "(map2 (\<squnion>) (map \<sigma> (var_rule \<alpha>)) Bs) = (map2 (\<squnion>) Bs (map \<sigma> (var_rule \<alpha>)))"
      by (smt fst_conv length_map length_zip map_eq_conv' min_less_iff_conj nth_mem nth_zip prod.case_eq_if snd_conv)
    then show ?thesis unfolding join.simps sigma
      by simp
  qed simp
qed simp_all


lemma join_with_source:
  assumes "A \<in> wf_pterm R"
  shows "A \<squnion> to_pterm (source A) = Some A"
using assms proof(induct A)
  case (2 As f)
  then have "\<forall>i < length As. (map2 (\<squnion>) As (map to_pterm (map source As)))!i = Some (As!i)"
    by simp
  then have "those (map2 (\<squnion>) As (map to_pterm (map source As))) = Some As"
    by (simp add: those_some)
  then show ?case
    by simp
next
  case (3 \<alpha> As)
  then have "\<forall>i < length As. (map2 (\<squnion>) As (map to_pterm (map source As)))!i = Some (As!i)"
    by simp
  then have IH:"those (map2 (\<squnion>) As (map to_pterm (map source As))) = Some As"
    by (simp add: those_some)
  from 3(1) have match:"match (to_pterm (source (Prule \<alpha> As))) (to_pterm (lhs \<alpha>)) = Some (\<langle>map (to_pterm \<circ> source) As\<rangle>\<^sub>\<alpha>)"
    by (metis (no_types, lifting) fun_mk_subst lhs_subst_trivial map_map source.simps(3) to_pterm.simps(1) to_pterm_subst)
  from 3(2) have "(map (\<langle>map (to_pterm \<circ> source) As\<rangle>\<^sub>\<alpha>) (var_rule \<alpha>)) = map (to_pterm \<circ> source) As"
    by (metis apply_lhs_subst_var_rule length_map)
  with IH match join.simps(4,5) show ?case by(cases "source (Prule \<alpha> As)") simp_all
qed simp

lemma join_subst:
  assumes varcond:"\<And>l r. (l, r) \<in> R \<Longrightarrow> is_Fun l"
    and "B \<in> wf_pterm R" and "\<forall>x \<in> vars_term B. \<rho> x \<in> wf_pterm R"
    and "\<forall>x \<in> vars_term B. source (\<rho> x) = \<sigma> x"
  shows "(B \<cdot> (to_pterm \<circ> \<sigma>)) \<squnion> ((to_pterm (source B)) \<cdot> \<rho>) = Some (B \<cdot> \<rho>)"
  using assms(2-) proof(induct B)
  case (1 x)
  then show ?case unfolding eval_term.simps source.simps to_pterm.simps o_apply
    using join_with_source by (metis term.set_intros(3) union_sym)
next
  case (2 ts f)
  {fix i assume i:"i < length ts"
    with 2 have "((ts!i) \<cdot> (to_pterm \<circ> \<sigma>)) \<squnion> ((to_pterm (source (ts!i))) \<cdot> \<rho>) = Some (ts!i \<cdot> \<rho>)"
      by (meson nth_mem term.set_intros(4))
    then have "map2 (\<squnion>) (map (\<lambda>t. t \<cdot> (to_pterm \<circ> \<sigma>)) ts) (map (\<lambda>t. t \<cdot> \<rho>) (map to_pterm (map source ts)))!i = Some ((map (\<lambda>t. t \<cdot> \<rho>) ts)!i)"
      using i by fastforce
  }
  then have "those (map2 (\<squnion>) (map (\<lambda>t. t \<cdot> (to_pterm \<circ> \<sigma>)) ts) (map (\<lambda>t. t \<cdot> \<rho>) (map to_pterm (map source ts)))) = Some (map (\<lambda>t. t \<cdot> \<rho>) ts)"
    using those_some by (smt (verit) length_map length_zip min.idem)
  then show ?case
    unfolding source.simps to_pterm.simps eval_term.simps using join.simps(2) by auto
next
  case (3 \<alpha> As)
  from 3(1) varcond obtain f ts where f:"lhs \<alpha> = Fun f ts"
     by fastforce
  obtain \<tau> where match:"match (to_pterm (lhs \<alpha> \<cdot> \<langle>map source As\<rangle>\<^sub>\<alpha>) \<cdot> \<rho>) (to_pterm (lhs \<alpha>)) = Some \<tau>"
    and \<tau>:"(\<forall>x\<in>vars_term (lhs \<alpha>). \<tau> x = ((to_pterm \<circ> \<langle>map source As\<rangle>\<^sub>\<alpha>) \<circ>\<^sub>s \<rho>) x)"
    using match_complete' unfolding to_pterm_subst by (smt (verit, best) set_vars_term_list subst_subst vars_to_pterm)
  {fix i assume i:"i < length (var_rule \<alpha>)"
    let ?x ="var_rule \<alpha> ! i"
    have "((to_pterm \<circ> \<langle>map source As\<rangle>\<^sub>\<alpha>) \<circ>\<^sub>s \<rho>) ?x = to_pterm (source (As!i)) \<cdot> \<rho>"
      using i 3(2) by (simp add: mk_subst_distinct subst_compose_def)
    moreover from 3 have "((As!i) \<cdot> (to_pterm \<circ> \<sigma>)) \<squnion> (to_pterm (source (As!i)) \<cdot> \<rho>) = Some ((As!i) \<cdot> \<rho>)"
      by (metis (mono_tags, lifting) i nth_mem term.set_intros(4))
    ultimately have "((As!i) \<cdot> (to_pterm \<circ> \<sigma>)) \<squnion> (\<tau> ?x) = Some ((As!i) \<cdot> \<rho>)"
      using \<tau> by (metis comp_apply i nth_mem set_remdups set_rev set_vars_term_list)
    then have "(map2 (\<squnion>) (map (\<lambda>t. t \<cdot> (to_pterm \<circ> \<sigma>)) As) (map \<tau> (var_rule \<alpha>)))!i = Some ((map (\<lambda>t. t \<cdot> \<rho>) As)!i)"
      using 3(2) i by auto
  }
  then have "those (map2 (\<squnion>) (map (\<lambda>t. t \<cdot> (to_pterm \<circ> \<sigma>)) As) (map \<tau> (var_rule \<alpha>))) = Some (map (\<lambda>t. t \<cdot> \<rho>) As)"
    by (simp add: 3(2) those_some)
  then show ?case
    using match unfolding source.simps to_pterm.simps eval_term.simps f using join.simps(5) f by auto
qed

text\<open>Analogous to residuals there are 6 lemmas corresponding to the step cases in induction proofs for joins.\<close>
lemma join_fun_fun:
  assumes "(Pfun f As) \<squnion> (Pfun g Bs) = Some C"
  shows "f = g \<and> length As = length Bs \<and>
        (\<exists>Cs. C = Pfun f Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. As!i \<squnion> Bs!i = Some (Cs!i)))"
proof-
  have *:"f = g \<and> length As = length Bs"
    using assms join.simps(2) by (metis option.simps(3))
  then obtain Cs where Cs:"those (map2 (\<squnion>) As Bs) = Some Cs"
    using assms option.simps(3) option.simps(4) by fastforce
  hence "\<forall>i < length As. As!i \<squnion> Bs!i = Some (Cs!i)"
    using * those_some2 by fastforce
  with * Cs assms(1) show ?thesis
    using length_those by fastforce
qed

lemma join_rule_rule:
  assumes "(Prule \<alpha> As) \<squnion> (Prule \<beta> Bs) = Some C"
          "(Prule \<alpha> As) \<in> wf_pterm R"
          "(Prule \<beta> Bs) \<in> wf_pterm R"
  shows "\<alpha> = \<beta> \<and> length As = length Bs \<and>
        (\<exists>Cs. C = Prule \<alpha> Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. As!i \<squnion> Bs!i = Some (Cs!i)))"
proof-
  have "\<alpha> = \<beta>"
    using assms(1) join.simps(3) by (metis option.simps(3))
  with assms(2,3) have l: "length As = length Bs"
    using length_args_well_Prule by blast
  from \<open>\<alpha> = \<beta>\<close> obtain Cs where Cs:"those (map2 (\<squnion>) As Bs) = Some Cs"
    using assms by fastforce
  hence "\<forall>i < length As. As!i \<squnion> Bs!i = Some (Cs!i)"
    using l those_some2 by fastforce
  with \<open>\<alpha> = \<beta>\<close> l Cs assms(1) show ?thesis
    using length_those by fastforce
qed

lemma join_rule_var:
  assumes "(Prule \<alpha> As) \<squnion> (Var x) = Some C"
          "(Prule \<alpha> As) \<in> wf_pterm R"
  shows "\<exists>\<sigma>. match (Var x) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and>
        (\<exists>Cs. C = Prule \<alpha> Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. As!i \<squnion> (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i)))"
proof-
  from assms(2) have l:"length As = length (var_rule \<alpha>)"
    using wf_pterm.cases by auto
  obtain \<sigma> where \<sigma>:"match (Var x) (to_pterm (lhs \<alpha>)) = Some \<sigma>"
    using assms(1) by fastforce
  then obtain Cs where Cs:"those (map2 (\<squnion>) As (map \<sigma> (var_rule \<alpha>))) = Some Cs"
    using assms(1) by fastforce
  with l have l2:"length Cs = length As"
    using length_those by fastforce
  from Cs have "\<forall>i < length As. As!i \<squnion> (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i)"
    using l those_some2 by fastforce
  with \<sigma> Cs assms(1) l2 show ?thesis by simp
qed

lemma join_rule_fun:
  assumes "(Prule \<alpha> As) \<squnion> (Pfun f Bs) = Some C"
          "(Prule \<alpha> As) \<in> wf_pterm R"
  shows "\<exists>\<sigma>. match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and>
        (\<exists>Cs. C = Prule \<alpha> Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. As!i \<squnion> (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i)))"
proof-
  from assms(2) have l:"length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  obtain \<sigma> where \<sigma>:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma>"
    using assms(1) by fastforce
  then obtain Cs where Cs:"those (map2 (\<squnion>) As (map \<sigma> (var_rule \<alpha>))) = Some Cs"
    using assms(1) by fastforce
  with l have l2:"length Cs = length As"
    using length_those by fastforce
  from Cs have "\<forall>i < length As. As!i \<squnion> (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i)"
    using l those_some2 by fastforce
  with \<sigma> Cs assms(1) l2 show ?thesis by auto
qed

lemma join_wf_pterm:
  assumes "A \<squnion> B = Some C"
    and "A \<in> wf_pterm R" and "B \<in> wf_pterm R"
  shows "C \<in> wf_pterm R"
  using assms proof(induct A B arbitrary:C rule:join.induct)
  case (1 x y)
  then show ?case
    by (metis join.simps(1) option.discI with_bot_iff)
next
  case (2 f As g Bs)
  then obtain Cs where "f = g \<and> length As = length Bs \<and>
        C = Pfun f Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. As!i \<squnion> Bs!i = Some (Cs!i))"
    by (meson join_fun_fun)
  moreover with 2 have "i < length As \<Longrightarrow> Cs!i \<in> wf_pterm R" for i
    using fun_well_arg by (metis (no_types, opaque_lifting) fst_conv in_set_zip nth_mem snd_conv)
  ultimately show ?case
    by (metis in_set_conv_nth wf_pterm.intros(2))
next
  case (3 \<alpha> As \<beta> Bs)
  then obtain Cs where "\<alpha> = \<beta> \<and> length As = length Bs \<and>
        (C = Prule \<alpha> Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. As!i \<squnion> Bs!i = Some (Cs!i)))"
    by (meson join_rule_rule)
  moreover with 3 have "i < length As \<Longrightarrow> Cs!i \<in> wf_pterm R" for i
    using fun_well_arg by (metis (no_types, opaque_lifting) fst_conv in_set_zip nth_mem snd_conv)
  moreover from 3(3) have "to_rule \<alpha> \<in> R"
    using wf_pterm.simps by fastforce
  ultimately show ?case
    by (smt (verit, best) "3.prems"(2) in_set_idx old.sum.distinct(2) term.distinct(1) term.inject(2) wf_pterm.cases wf_pterm.intros(3))
next
  case ("4_1" \<alpha> As v)
  then obtain Cs \<sigma> where *:"match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and>
        C = Prule \<alpha> Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. As!i \<squnion> (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i))"
    by (meson join_rule_var)
  from "4_1"(3) have wellA:"\<forall>i < length As. As!i \<in> wf_pterm R"
    by auto
  from "4_1"(3) have l: "length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  then have l2:"length As = length (zip As (map \<sigma> (var_rule \<alpha>)))"
    by simp
  from l * have "\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R"
    using "4_1"(4) by (metis match_well_def vars_to_pterm)
  with "4_1"(1) * wellA l2 have "\<forall>i < length As. Cs!i \<in> wf_pterm R"
    by (smt (z3) l length_map nth_map nth_mem nth_zip)
  with "4_1"(3) * show ?case
    by (smt (verit) Inr_not_Inl in_set_conv_nth term.distinct(1) term.inject(2) wf_pterm.cases wf_pterm.intros(3))
next
  case ("4_2" \<alpha> As f Bs)
  then obtain \<sigma> Cs where *:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and>
        (C = Prule \<alpha> Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. As!i \<squnion> (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i)))"
    by (meson join_rule_fun)
  from "4_2"(3) have wellA:"\<forall>i < length As. As!i \<in> wf_pterm R"
    by auto
  from "4_2"(3) have l: "length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  then have l2:"length As = length (zip As (map \<sigma> (var_rule \<alpha>)))"
    by simp
  from l * have "\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R"
    using "4_2"(4) by (metis match_well_def vars_to_pterm)
  with "4_2"(1) * wellA l2 have "\<forall>i < length As. Cs!i \<in> wf_pterm R"
    by (smt l length_map nth_map nth_mem nth_zip)
  with "4_2"(3) * show ?case
    by (smt (verit, ccfv_threshold) Inr_not_Inl in_set_conv_nth term.distinct(1) term.inject(2) wf_pterm.cases wf_pterm.intros(3))
next
  case ("5_1" v \<alpha> As)
  then obtain Cs \<sigma> where *:"match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and>
        C = Prule \<alpha> Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. (\<sigma> (var_rule \<alpha> ! i)) \<squnion> As!i = Some (Cs!i))"
    using join_rule_var by (metis union_sym)
  from "5_1"(4) have wellA:"\<forall>i < length As. As!i \<in> wf_pterm R"
    by auto
  from "5_1"(4) have l: "length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  then have l2:"length As = length (zip As (map \<sigma> (var_rule \<alpha>)))"
    by simp
  from l * have "\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R"
    using "5_1"(3) by (metis match_well_def vars_to_pterm)
  with "5_1"(1) * wellA l2 l have "\<forall>i < length As. Cs!i \<in> wf_pterm R"
    by (smt (verit, del_insts) length_map nth_map nth_mem nth_zip zip_symm)
  with "5_1"(4) * show ?case
    by (smt (verit) Inr_not_Inl in_set_conv_nth term.distinct(1) term.inject(2) wf_pterm.cases wf_pterm.intros(3))
next
  case ("5_2" f Bs \<alpha> As)
  then obtain Cs \<sigma> where *:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and>
        C = Prule \<alpha> Cs  \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. (\<sigma> (var_rule \<alpha> ! i)) \<squnion> As!i = Some (Cs!i))"
    using union_sym join_rule_fun by metis
  from "5_2"(4) have wellA:"\<forall>i < length As. As!i \<in> wf_pterm R"
    by auto
  from "5_2"(4) have l: "length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  then have l2:"length As = length (zip (map \<sigma> (var_rule \<alpha>)) As)"
    by simp
  from l * have "\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R"
    using "5_2"(3) by (metis match_well_def vars_to_pterm)
  with "5_2"(1) * wellA l2 have "\<forall>i < length As. Cs!i \<in> wf_pterm R"
    by (smt l length_map nth_map nth_mem nth_zip)
  with * show ?case
    by (metis "5_2.prems"(3) Inl_inject Inr_not_Inl in_set_idx l term.distinct(1) term.sel(2) wf_pterm.cases wf_pterm.intros(3))
qed auto

lemma source_join:
  assumes "A \<squnion> B = Some C"
    and "A \<in> wf_pterm R" and "B \<in> wf_pterm R"
  shows "co_initial A C"
  using assms proof(induct A B arbitrary:C rule:join.induct)
  case (1 x y)
  then show ?case
    by (metis join.simps(1) option.discI option.sel)
next
  case (2 f As g Bs)
  then obtain Cs where "f = g \<and> length As = length Bs \<and>
        C = Pfun f Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. As!i \<squnion> Bs!i = Some (Cs!i))"
    by (meson join_fun_fun)
  moreover with 2 have "i < length As \<Longrightarrow> co_initial (As!i) (Cs!i)" for i
    using fun_well_arg by (metis (no_types, opaque_lifting) fst_conv in_set_zip nth_mem snd_conv)
  ultimately show ?case
    by (simp add: nth_map_conv)
next
  case (3 \<alpha> As \<beta> Bs)
  then obtain Cs where "\<alpha> = \<beta> \<and> length As = length Bs \<and>
        (C = Prule \<alpha> Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. As!i \<squnion> Bs!i = Some (Cs!i)))"
    by (meson join_rule_rule)
  moreover with 3 have "i < length As \<Longrightarrow> co_initial (As!i) (Cs!i)" for i
    using fun_well_arg by (metis (no_types, opaque_lifting) fst_conv in_set_zip nth_mem snd_conv)
  ultimately show ?case
    by (metis (mono_tags, lifting) map_eq_conv' source.simps(3))
next
  case ("4_1" \<alpha> As v)
  then obtain Cs \<sigma> where *:"match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and>
        C = Prule \<alpha> Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. As!i \<squnion> (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i))"
    by (meson join_rule_var)
  from "4_1"(3) have wellA:"\<forall>i < length As. As!i \<in> wf_pterm R"
    by auto
  from "4_1"(3) have l: "length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  then have l2:"length As = length (zip As (map \<sigma> (var_rule \<alpha>)))"
    by simp
  from l * have "\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R"
    using "4_1"(4) by (metis match_well_def vars_to_pterm)
  with "4_1"(1) * wellA l2 have "\<forall>i < length As. co_initial (As!i) (Cs!i)"
    by (smt (z3) l length_map nth_map nth_mem nth_zip)
  with "4_1"(3) * show ?case
    by (metis nth_map_conv source.simps(3))
next
  case ("4_2" \<alpha> As f Bs)
  then obtain \<sigma> Cs where *:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma> \<and>
        (C = Prule \<alpha> Cs \<and>
        length Cs = length As \<and>
        (\<forall>i < length As. As!i \<squnion> (\<sigma> (var_rule \<alpha> ! i)) = Some (Cs!i)))"
    by (meson join_rule_fun)
  from "4_2"(3) have wellA:"\<forall>i < length As. As!i \<in> wf_pterm R"
    by auto
  from "4_2"(3) have l: "length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  then have l2:"length As = length (zip As (map \<sigma> (var_rule \<alpha>)))"
    by simp
  from l * have "\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R"
    using "4_2"(4) by (metis match_well_def vars_to_pterm)
  with "4_2"(1) * wellA l2 have "\<forall>i < length As. co_initial (As!i) (Cs!i)"
    by (smt l length_map nth_map nth_mem nth_zip)
  with "4_2"(3) * show ?case
    by (metis nth_map_conv source.simps(3))
next
  case ("5_1" v \<alpha> As)
  then obtain Cs \<sigma> where *:"match (Var v) (to_pterm (lhs \<alpha>)) = Some \<sigma>"
       "C = Prule \<alpha> Cs"
       "length Cs = length As \<and>
        (\<forall>i < length As. (\<sigma> (var_rule \<alpha> ! i)) \<squnion> As!i = Some (Cs!i))"
    using join_rule_var by (metis union_sym)
  from "5_1"(4) have wellA:"\<forall>i < length As. As!i \<in> wf_pterm R"
    by auto
  from "5_1"(4) have l: "length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  then have l2:"length As = length (zip As (map \<sigma> (var_rule \<alpha>)))"
    by simp
  from l * have "\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R"
    using "5_1"(3) by (metis match_well_def vars_to_pterm)
  with "5_1"(1) * wellA l2 l have IH:"\<forall>i < length As. co_initial ((map \<sigma> (var_rule \<alpha>))!i) (Cs!i)"
    by (smt (verit, del_insts) length_map nth_map nth_mem nth_zip zip_symm)
  moreover have v:"Var v = (to_pterm (lhs \<alpha>)) \<cdot> \<langle>(map \<sigma> (var_rule \<alpha>))\<rangle>\<^sub>\<alpha>"
    using * by (smt (verit, ccfv_threshold) apply_lhs_subst_var_rule map_eq_conv match_lhs_subst)
  show ?case using IH l unfolding v *(2) source.simps
    by (metis "*"(1,3) fun_mk_subst length_map lhs_subst_trivial nth_map_conv option.inject source.simps(1) source_apply_subst source_to_pterm to_pterm_wf_pterm v)
next
  case ("5_2" f Bs \<alpha> As)
  then obtain Cs \<sigma> where *:"match (Pfun f Bs) (to_pterm (lhs \<alpha>)) = Some \<sigma>"
       "C = Prule \<alpha> Cs"
       "length Cs = length As \<and>
        (\<forall>i < length As. (\<sigma> (var_rule \<alpha> ! i)) \<squnion> As!i = Some (Cs!i))"
    using join_rule_fun by (metis union_sym)
  from "5_2"(4) have wellA:"\<forall>i < length As. As!i \<in> wf_pterm R"
    by auto
  from "5_2"(4) have l: "length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  then have l2:"length As = length (zip As (map \<sigma> (var_rule \<alpha>)))"
    by simp
  from l * have "\<forall>i < length As. \<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R"
    using "5_2"(3) by (metis match_well_def vars_to_pterm)
  with "5_2"(1) * wellA l2 l have IH:"\<forall>i < length As. co_initial ((map \<sigma> (var_rule \<alpha>))!i) (Cs!i)"
    by (smt (verit, del_insts) length_map nth_map nth_mem nth_zip zip_symm)
  moreover have f:"Pfun f Bs = (to_pterm (lhs \<alpha>)) \<cdot> \<langle>(map \<sigma> (var_rule \<alpha>))\<rangle>\<^sub>\<alpha>"
    using * by (smt (verit, ccfv_threshold) apply_lhs_subst_var_rule map_eq_conv match_lhs_subst)
  show ?case using IH l unfolding f *(2) source.simps
    by (metis "*"(3) fun_mk_subst length_map nth_map_conv source.simps(1) source_apply_subst source_to_pterm to_pterm_wf_pterm)
qed auto

section\<open>Deletion\<close>
fun deletion :: "('f, 'v) pterm \<Rightarrow> ('f,'v) pterm \<Rightarrow> ('f,'v) pterm option" (infixr "-\<^sub>p" 70)
  where
  "Var x -\<^sub>p Var y =
    (if x = y then Some (Var x) else None)"
| "Pfun f As -\<^sub>p Pfun g Bs =
    (if (f = g \<and> length As = length Bs) then
      (case those (map2 (-\<^sub>p) As Bs) of
        Some xs \<Rightarrow> Some (Pfun f xs)
      | None \<Rightarrow> None)
    else None)"
| "Prule \<alpha> As -\<^sub>p Prule \<beta> Bs =
    (if \<alpha> = \<beta> then
      (case those (map2 (-\<^sub>p) As Bs) of
        Some xs \<Rightarrow> Some ((to_pterm (lhs \<alpha>)) \<cdot> \<langle>xs\<rangle>\<^sub>\<alpha>)
      | None \<Rightarrow> None)
    else None)"
| "Prule \<alpha> As -\<^sub>p B =
    (case match B (to_pterm (lhs \<alpha>)) of
      None \<Rightarrow> None
    | Some \<sigma> \<Rightarrow>
      (case those (map2 (-\<^sub>p) As (map \<sigma> (var_rule \<alpha>))) of
        Some xs \<Rightarrow> Some (Prule \<alpha> xs)
      | None \<Rightarrow> None))"
| "A -\<^sub>p B = None"

lemma del_empty:
  assumes "A \<in> wf_pterm R"
  shows "A -\<^sub>p (to_pterm (source A)) = Some A"
using assms proof (induction A)
  case (2 As f)
  then have "those (map2 deletion As (map (to_pterm \<circ> source) As)) = Some As" by (simp add:those_some)
  then show ?case by simp
next
  case (3 \<alpha> As)
  then have \<sigma>: "match (to_pterm (lhs \<alpha> \<cdot> \<langle>map source As\<rangle>\<^sub>\<alpha>)) (to_pterm (lhs \<alpha>)) = Some (\<langle>map (to_pterm \<circ> source) As\<rangle>\<^sub>\<alpha>)"
    by (metis (no_types, lifting) fun_mk_subst lhs_subst_trivial map_map to_pterm.simps(1) to_pterm_subst)
  from 3 have "those (map2 deletion As (map (to_pterm \<circ> source) As)) = Some As"
    by (simp add:those_some)
  then have args:"those (map2 deletion As (map (\<langle>map (to_pterm \<circ> source) As\<rangle>\<^sub>\<alpha>) (var_rule \<alpha>))) = Some As"
    by (metis "3.hyps"(2) apply_lhs_subst_var_rule length_map)
  show ?case proof(cases "source (Prule \<alpha> As)")
    case (Var x)
    then show ?thesis
      using \<sigma> residual.simps(4)[of \<alpha> As x] args by auto
  next
    case (Fun f ts)
    then show ?thesis
      using \<sigma> residual.simps(5)[of \<alpha> As f] args by auto
  qed
qed simp

lemma deletion_source:
  assumes varcond:"\<And>l r. (l, r) \<in> R \<Longrightarrow> is_Fun l"
    and "A \<in> wf_pterm R" "B \<in> wf_pterm R"
    and "A -\<^sub>p B = Some C"
  shows "source C = source A"
  using assms(2-) proof(induct A arbitrary:B C)
  case (1 x)
  then show ?case proof (cases B)
    case (1 y)
    then show ?thesis
      by (metis "1.prems"(2) deletion.simps(1) option.distinct(1) option.inject)
  next
    case (3 \<alpha> As)
    with 1 varcond show ?thesis
      by simp
  qed simp
next
  case (2 As f)
  then show ?case proof(cases B)
    case (Pfun g Bs)
    from 2(3) have f:"f = g"
      unfolding Pfun by (metis deletion.simps(2) not_None_eq)
    from 2(3) have l:"length As = length Bs"
      unfolding Pfun by (metis deletion.simps(2) not_None_eq)
    from 2(3) obtain Cs where cs:"those (map2 (-\<^sub>p) As Bs) = Some Cs"
      unfolding Pfun f using l by fastforce
    with 2(3) have c:"C = Pfun g Cs"
      unfolding Pfun by (simp add: f l)
    from cs l have l_cs:"length Cs = length As"
      using length_those by force
    {fix i assume i:"i < length As"
      with 2(2) have "Bs!i \<in> wf_pterm R"
        by (metis Pfun fun_well_arg l nth_mem)
      moreover from 2(3) i cs have "As!i -\<^sub>p Bs!i = Some (Cs!i)"
        using l those_some2 by fastforce
      ultimately have "source (Cs!i) = source (As!i)"
        using 2(1) using i nth_mem by blast
    }
    then show ?thesis unfolding c f
      using l_cs by (simp add: map_nth_eq_conv)
  qed simp_all
next
  case (3 \<alpha> As)
  from 3(1) varcond obtain f ts where f:"lhs \<alpha> = Fun f ts"
    by blast
  then show ?case proof(cases B)
    case (Var x)
    have "match (Var x) (to_pterm (lhs \<alpha>)) = None"
      unfolding f by (smt (verit, ccfv_SIG) Term.term.simps(4) match_matches not_Some_eq source.simps(1) source_to_pterm subst_apply_eq_Var)
    with 3(5) show ?thesis
      unfolding Var using f deletion.simps(4) by simp
  next
    case (Pfun g Bs)
    from 3(5) obtain \<sigma> where sigma:"match B (to_pterm (lhs \<alpha>)) = Some \<sigma>"
      unfolding Pfun using deletion.simps(5) by fastforce
    with 3(5) obtain Cs where cs:"those (map2 (-\<^sub>p) As (map \<sigma> (var_rule \<alpha>))) = Some Cs"
      unfolding Pfun by fastforce
    with 3(5) have c:"C = Prule \<alpha> Cs"
      using sigma unfolding Pfun by simp
    from cs 3(2) have l_cs:"length Cs = length As"
      using length_those by force
    {fix x assume "x \<in> vars_term (lhs \<alpha>)"
      then obtain i where i:"i < length (var_rule \<alpha>)" "var_rule \<alpha> !i = x"
        by (metis in_set_conv_nth set_vars_term_list vars_term_list_var)
      then have "\<sigma> (var_rule \<alpha> ! i) \<in> wf_pterm R"
        using match_well_def[OF 3(4) sigma] by (metis vars_to_pterm)
      moreover from i cs have "As!i -\<^sub>p \<sigma> (var_rule \<alpha> ! i) = Some (Cs!i)"
        using those_some2 "3.hyps"(2) by fastforce
      ultimately have "source (Cs!i) = source (As!i)"
        using 3(3) using i nth_mem "3.hyps"(2) by force
      then have "source ((\<langle>As\<rangle>\<^sub>\<alpha>) x) = source ((\<langle>Cs\<rangle>\<^sub>\<alpha>) x)" using i
        by (metis "3.hyps"(2) l_cs lhs_subst_var_i)
    }
    then show ?thesis unfolding c using l_cs 3(2) unfolding source.simps
      by (smt (verit, best) apply_lhs_subst_var_rule comp_def in_set_conv_nth length_map nth_map set_remdups set_rev set_vars_term_list term_subst_eq_conv)
  next
    case (Prule \<beta> Bs)
    from 3(5) have alpha:"\<alpha> = \<beta>"
      unfolding Prule by (metis deletion.simps(3) option.distinct(1))
    with 3 have l:"length As = length Bs"
      unfolding Prule using wf_pterm.cases by force
    from 3(5) obtain Cs where cs:"those (map2 (-\<^sub>p) As Bs) = Some Cs"
      unfolding Prule alpha by fastforce
    with 3(5) have c:"C = to_pterm (lhs \<alpha>) \<cdot> \<langle>Cs\<rangle>\<^sub>\<alpha>"
      unfolding Prule alpha by simp
    from cs l have l_cs:"length Cs = length As"
      using length_those by force
    {fix i assume i:"i < length As"
      with 3(4) have "Bs!i \<in> wf_pterm R"
        unfolding Prule by (metis fun_well_arg l nth_mem)
      moreover from i cs have "As!i -\<^sub>p Bs!i = Some (Cs!i)"
        using l those_some2 by fastforce
      ultimately have "source (Cs!i) = source (As!i)"
        using 3(3) using i nth_mem by blast
    }
    then show ?thesis
      unfolding c using l_cs unfolding source.simps using source_apply_subst
      by (metis fun_mk_subst nth_map_conv source.simps(1) source_to_pterm to_pterm_wf_pterm)
  qed
qed

section\<open>Single redexes\<close>
text\<open>ll stands for left-linear, since this definition only makes sense for left-linear rules.\<close>
definition ll_single_redex :: "('f, 'v) term \<Rightarrow> pos \<Rightarrow> ('f, 'v) prule \<Rightarrow> ('f, 'v) pterm"
  where "ll_single_redex s p \<alpha> = (ctxt_of_pos_term p (to_pterm s))\<langle>Prule \<alpha> (map (to_pterm \<circ> (\<lambda>pi. s|_(p@pi))) (var_poss_list (lhs \<alpha>)))\<rangle>"

lemma source_single_redex:
  assumes "p \<in> poss s"
  shows "source (ll_single_redex s p \<alpha>) = (ctxt_of_pos_term p s)\<langle>(lhs \<alpha>) \<cdot> \<langle>map (\<lambda>pi. s|_(p@pi)) (var_poss_list (lhs \<alpha>))\<rangle>\<^sub>\<alpha>\<rangle>"
proof-
  have "source (Prule \<alpha> (map (to_pterm \<circ> (\<lambda>pi. s|_(p@pi))) (var_poss_list (lhs \<alpha>)))) = (lhs \<alpha>) \<cdot> \<langle>map (\<lambda>pi. s|_(p@pi)) (var_poss_list (lhs \<alpha>))\<rangle>\<^sub>\<alpha>"
    unfolding source.simps using map_nth_eq_conv by fastforce 
  with assms show ?thesis
    unfolding ll_single_redex_def by (metis context_source source_to_pterm to_pterm_ctxt_of_pos_apply_term) 
qed

lemma target_single_redex:
  assumes "p \<in> poss s"
  shows "target (ll_single_redex s p \<alpha>) = (ctxt_of_pos_term p s)\<langle>(rhs \<alpha>) \<cdot> \<langle>map (\<lambda>pi. s|_(p@pi)) (var_poss_list (lhs \<alpha>))\<rangle>\<^sub>\<alpha>\<rangle>"
proof-
  have "target (Prule \<alpha> (map (to_pterm \<circ> (\<lambda>pi. s|_(p@pi))) (var_poss_list (lhs \<alpha>)))) = (rhs \<alpha>) \<cdot> \<langle>map (\<lambda>pi. s|_(p@pi)) (var_poss_list (lhs \<alpha>))\<rangle>\<^sub>\<alpha>"
    unfolding target.simps by (metis (no_types, lifting) fun_mk_subst map_map target_empty_apply_subst target_to_pterm to_pterm.simps(1) to_pterm_empty to_pterm_subst)
  with assms show ?thesis
    unfolding ll_single_redex_def using target_to_pterm_ctxt to_pterm_ctxt_at_pos by metis
qed

lemma single_redex_rstep:
  assumes "to_rule \<alpha> \<in> R" "p \<in> poss s"
  shows "(source (ll_single_redex s p \<alpha>), target (ll_single_redex s p \<alpha>)) \<in> rstep R"
using source_single_redex target_single_redex assms by blast

text \<open>Interaction of a proof term A with a proof term \<Delta> contracting only a single redex of A\<close>
locale single_redex =
  fixes R A \<Delta> p q \<alpha>
  assumes a_well:"A \<in> wf_pterm R"
    and left_lin:"left_linear_trs R" and varcond:"\<And>l r. (l, r) \<in> R \<Longrightarrow> is_Fun l"
    and p:"p \<in> poss (source A)" and q:"q \<in> poss A"
    and pq:"ctxt_of_pos_term p (source A) = source_ctxt (ctxt_of_pos_term q A)"
    and delta:"\<Delta> = ll_single_redex (source A) p \<alpha>"
    and aq:"A|_q = Prule \<alpha> (map (\<lambda>i. A|_(q@[i])) [0..<length (var_rule \<alpha>)])"
begin

interpretation residual_op:op_proof_term "R" "residual"
  using op_proof_term.intro[OF left_lin, of residual] varcond res_empty2 by force

interpretation deletion_op:op_proof_term "R" "deletion"
  using op_proof_term.intro[OF left_lin, of deletion] varcond del_empty  by force

abbreviation "As \<equiv> (map (\<lambda>i. A|_(q@[i])) [0..<length (var_rule \<alpha>)])"

lemma length_as:"length As = length (var_rule \<alpha>)"
  by simp

lemma as_well:"\<forall>i < length As. As!i \<in> wf_pterm R"
  using subt_at_is_wf_pterm a_well aq q
  by (metis fun_well_arg nth_mem)

lemma a:"A = (ctxt_of_pos_term q A)\<langle>Prule \<alpha> As\<rangle>"
  using aq by (simp add: q replace_at_ident)

lemma rule_in_TRS: "to_rule \<alpha> \<in> R"
proof-
   from a_well a q have "Prule \<alpha> As \<in> wf_pterm R"
    by (metis subt_at_ctxt_of_pos_term subt_at_is_wf_pterm)
  then show ?thesis
    using wf_pterm.cases by force
qed

lemma lin_lhs:"linear_term (lhs \<alpha>)"
  using rule_in_TRS left_lin left_linear_trs_def by fastforce

lemma source_at_pq:"source (A|_q) = (source A)|_p"
proof-
  from a_well q have "(ctxt_of_pos_term q A) \<in> wf_pterm_ctxt R"
    by (simp add: ctxt_of_pos_term_well)
  then have "source A = (source_ctxt (ctxt_of_pos_term q A)) \<langle>source (A|_q)\<rangle>"
    using source_ctxt_apply_term[OF left_lin] q by (metis ctxt_supt_id)
  moreover from p have "source A = (ctxt_of_pos_term p (source A)) \<langle>(source A)|_p\<rangle>"
    by (simp add: replace_at_ident)
  ultimately show ?thesis
    using pq p q by simp
qed

lemma single_redex_pterm:
  shows "\<Delta> = (ctxt_of_pos_term p (to_pterm (source A)))\<langle>Prule \<alpha> (map (to_pterm \<circ> source) As)\<rangle>"
proof-
  from lin_lhs have l2:"length (var_poss_list (lhs \<alpha>)) = length (var_rule \<alpha>)"
      by (metis length_var_poss_list linear_term_var_vars_term_list)
  {fix i assume i:"i < length (var_poss_list (lhs \<alpha>))"
    let ?pi="var_poss_list (lhs \<alpha>)!i"
    from i have *:"(lhs \<alpha>)|_?pi = Var ((var_rule \<alpha>)!i)"
      using lin_lhs by (metis linear_term_var_vars_term_list length_var_poss_list vars_term_list_var_poss_list)
    from source_at_pq have "source A |_ (p @ ?pi) = source (Prule \<alpha> As)|_?pi"
      by (metis a p q subt_at_append subt_at_ctxt_of_pos_term)
    also have "... = Var ((var_rule \<alpha>)!i) \<cdot> \<langle>map source As\<rangle>\<^sub>\<alpha>"
      unfolding source.simps using subt_at_subst * i nth_mem var_poss_imp_poss by fastforce
    also have "... = source (As!i)"
      unfolding eval_term.simps using i lhs_subst_var_i length_as l2 by (metis (no_types, lifting) length_map nth_map)
    finally have "source A |_ (p @ ?pi) = source (As!i)" .
  }
  with l2 show ?thesis
    unfolding delta ll_single_redex_def by (simp add: nth_map_conv)
qed

lemma delta_trs_wf_pterm:
 shows "\<Delta> \<in> wf_pterm R"
proof-
  have well2:"Prule \<alpha> (map (to_pterm \<circ> source) As) \<in> wf_pterm R" proof-
    from a_well a q have "Prule \<alpha> As \<in> wf_pterm R"
      by (metis subt_at_ctxt_of_pos_term subt_at_is_wf_pterm)
    then have "to_rule \<alpha> \<in> R"
      using wf_pterm.cases by auto
    then show ?thesis
      by (simp add: wf_pterm.intros(3))
  qed
  show ?thesis unfolding single_redex_pterm
    using p well2 by (simp add: p_in_poss_to_pterm ctxt_wf_pterm)
qed

lemma source_delta: "source \<Delta> = source A"
proof-
  have src:"source (Prule \<alpha> (map (to_pterm \<circ> source) As)) = source (Prule \<alpha> As)"
    unfolding source.simps by (metis (no_types, lifting) comp_eq_dest_lhs list.map_comp list.map_cong0 source_to_pterm)
  moreover have "source_ctxt (ctxt_of_pos_term p (to_pterm (source A))) = source_ctxt (ctxt_of_pos_term q A)"
    using pq by (metis p source_to_pterm_ctxt' to_pterm_ctxt_at_pos)
  ultimately show ?thesis unfolding single_redex_pterm
    using p p q by (metis aq left_lin p_in_poss_to_pterm pq replace_at_ident source_at_pq source_ctxt_apply_term to_pterm_trs_ctxt)
qed

lemma residual:
  shows "A re \<Delta> = Some ((ctxt_of_pos_term q A)\<langle>(to_pterm (rhs \<alpha>)) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>\<rangle>)"
proof-
  have l:"length (map2 (re) As (map (to_pterm \<circ> source) As)) = length As"
    by simp
  {fix i assume i:"i < length As"
    with as_well have "As!i re (to_pterm \<circ> source) (As!i) = Some (As!i)"
      by (metis (no_types, lifting) o_apply res_empty2)
    then have "map2 (re) As (map (to_pterm \<circ> source) As) ! i = Some (As ! i)"
      using i by force
  }
  then have *:"those (map2 (re) As (map (to_pterm \<circ> source) As)) = Some As"
    using those_some[OF l] using l by presburger
  then have "(Prule \<alpha> As) re (Prule \<alpha> (map (to_pterm \<circ> source) As)) = Some ((to_pterm (rhs \<alpha>)) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>)"
     using residual.simps(3)[of \<alpha> As \<alpha> "(map (to_pterm \<circ> source) As)"] by simp
  moreover from single_redex_pterm have "\<Delta> = (to_pterm_ctxt (source_ctxt (ctxt_of_pos_term q A)))\<langle>(Prule \<alpha> (map (to_pterm \<circ> source) As))\<rangle>"
    unfolding delta ll_single_redex_def pq[symmetric] by (simp add: p to_pterm_ctxt_at_pos)
  ultimately show ?thesis
    using a residual_op.apply_f_ctxt by (metis (no_types, lifting) ctxt_of_pos_term_well single_redex_axioms single_redex_def)
qed

lemma residual_well:
 "the (A re \<Delta>) \<in> wf_pterm R"
  using a_well by (metis delta_trs_wf_pterm option.sel residual residual_well_defined)

lemma target_residual:"target (the (A re \<Delta>)) = target A"
  apply(subst (2) a)
  unfolding residual option.sel
  apply(subst (1 2) context_target)
  by (metis fun_mk_subst target.simps(1) target.simps(3) target_empty_apply_subst target_to_pterm to_pterm_empty)


lemma deletion:
  shows "A -\<^sub>p \<Delta> = Some ((ctxt_of_pos_term q A)\<langle>(to_pterm (lhs \<alpha>)) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>\<rangle>)"
proof-
   have l:"length (map2 (-\<^sub>p) As (map (to_pterm \<circ> source) As)) = length As"
    by simp
  {fix i assume i:"i < length As"
    with as_well have "As!i -\<^sub>p (to_pterm \<circ> source) (As!i) = Some (As!i)"
      by (metis (no_types, lifting) o_apply del_empty)
    then have "map2 (-\<^sub>p) As (map (to_pterm \<circ> source) As) ! i = Some (As ! i)"
      using i by force
  }
  then have *:"those (map2 (-\<^sub>p) As (map (to_pterm \<circ> source) As)) = Some As"
    using those_some[OF l] using l by presburger
  then have "(Prule \<alpha> As) -\<^sub>p (Prule \<alpha> (map (to_pterm \<circ> source) As)) = Some ((to_pterm (lhs \<alpha>)) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>)"
     using deletion.simps(3)[of \<alpha> As \<alpha> "(map (to_pterm \<circ> source) As)"] by simp
  moreover from single_redex_pterm have "\<Delta> = (to_pterm_ctxt (source_ctxt (ctxt_of_pos_term q A)))\<langle>(Prule \<alpha> (map (to_pterm \<circ> source) As))\<rangle>"
    unfolding delta ll_single_redex_def pq[symmetric] by (simp add: p to_pterm_ctxt_at_pos)
  ultimately show ?thesis
    using a deletion_op.apply_f_ctxt by (metis (no_types, lifting) ctxt_of_pos_term_well single_redex_axioms single_redex_def)
qed

lemma deletion_well:
  shows "the (A -\<^sub>p \<Delta>) \<in> wf_pterm R"
proof-
  have "\<forall>a \<in> set As. a \<in> wf_pterm R"
    by (metis a a_well fun_well_arg q subt_at_ctxt_of_pos_term subt_at_is_wf_pterm)
  then have "to_pterm (lhs \<alpha>) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha> \<in> wf_pterm R"
    by (meson lhs_subst_well_def nth_mem to_pterm_wf_pterm)
  then show ?thesis unfolding deletion option.sel
    by (simp add: a_well ctxt_wf_pterm q)
qed
end

locale single_redex' =
  fixes R A \<Delta> p q \<alpha> \<sigma>
  assumes a_well:"A \<in> wf_pterm R" and rule_in_TRS:"to_rule \<alpha> \<in> R"
    and left_lin:"left_linear_trs R" and varcond:"\<And>l r. (l, r) \<in> R \<Longrightarrow> is_Fun l \<and> vars_term r \<subseteq> vars_term l"
    and p:"p \<in> poss (source A)" and q:"q \<in> poss A"
    and pq:"ctxt_of_pos_term p (source A) = source_ctxt (ctxt_of_pos_term q A)"
    and delta:"\<Delta> = ll_single_redex (source A) p \<alpha>"
    and aq:"A|_q = (to_pterm (lhs \<alpha>)) \<cdot> \<sigma>"
begin

interpretation residual_op:op_proof_term "R" "residual"
  using op_proof_term.intro[OF left_lin, of residual] varcond res_empty2 by force

lemma a:"A = (ctxt_of_pos_term q A)\<langle>(to_pterm (lhs \<alpha>)) \<cdot> \<sigma>\<rangle>"
  using aq by (simp add: q replace_at_ident)

lemma lin_lhs:"linear_term (lhs \<alpha>)"
  using rule_in_TRS left_lin left_linear_trs_def by fastforce

lemma is_fun_lhs:"is_Fun (lhs \<alpha>)"
  using rule_in_TRS using varcond by blast

abbreviation "As \<equiv> map \<sigma> (var_rule \<alpha>)"

lemma lhs_subst: "(to_pterm (lhs \<alpha>)) \<cdot> \<sigma> = (to_pterm (lhs \<alpha>)) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>"
proof-
  {fix x assume "x \<in> vars_term (to_pterm (lhs \<alpha>))"
    then obtain i where "x = var_rule \<alpha>!i" and "i < length (var_rule \<alpha>)"
      by (metis in_set_idx set_vars_term_list vars_term_list_var vars_to_pterm)
    then have "\<sigma> x = (\<langle>As\<rangle>\<^sub>\<alpha>) x"
      by (metis (mono_tags, lifting) apply_lhs_subst_var_rule length_map nth_map)
  }
  then show ?thesis
    using term_subst_eq_conv by blast
qed

lemma rhs_subst: "(to_pterm (rhs \<alpha>)) \<cdot> \<sigma> = (to_pterm (rhs \<alpha>)) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>"
proof-
  {fix x assume "x \<in> vars_term (to_pterm (rhs \<alpha>))"
    then have "x \<in> vars_term (to_pterm (lhs \<alpha>))"
      using varcond by (metis rule_in_TRS set_vars_term_list subsetD vars_to_pterm)
    then obtain i where "x = var_rule \<alpha>!i" and "i < length (var_rule \<alpha>)"
      by (metis in_set_idx set_vars_term_list vars_term_list_var vars_to_pterm)
    then have "\<sigma> x = (\<langle>As\<rangle>\<^sub>\<alpha>) x"
      by (metis (mono_tags, lifting) apply_lhs_subst_var_rule length_map nth_map)
  }
  then show ?thesis
    using term_subst_eq_conv by blast
qed

lemma as_well:"\<forall>i < length As. As!i \<in> wf_pterm R"
  using a_well aq by (metis length_map lhs_subst lhs_subst_args_wf_pterm nth_mem q subt_at_is_wf_pterm)

lemma source_at_pq:"source (A|_q) = (source A)|_p"
proof-
  from a_well q have "(ctxt_of_pos_term q A) \<in> wf_pterm_ctxt R"
    by (simp add: ctxt_of_pos_term_well)
  then have "source A = (source_ctxt (ctxt_of_pos_term q A)) \<langle>source (A|_q)\<rangle>"
    using source_ctxt_apply_term[OF left_lin] q by (metis ctxt_supt_id)
  moreover from p have "source A = (ctxt_of_pos_term p (source A)) \<langle>(source A)|_p\<rangle>"
    by (simp add: replace_at_ident)
  ultimately show ?thesis
    using pq p q by simp
qed

lemma single_redex_pterm:
  shows "\<Delta> = (ctxt_of_pos_term p (to_pterm (source A)))\<langle>Prule \<alpha> (map (to_pterm \<circ> source) As)\<rangle>"
proof-
  from lin_lhs have l2:"length (var_poss_list (lhs \<alpha>)) = length (var_rule \<alpha>)"
      by (metis length_var_poss_list linear_term_var_vars_term_list)
  {fix i assume i:"i < length (var_poss_list (lhs \<alpha>))"
    let ?pi="var_poss_list (lhs \<alpha>)!i"
    from i have *:"(lhs \<alpha>)|_?pi = Var ((var_rule \<alpha>)!i)"
      using lin_lhs by (metis linear_term_var_vars_term_list length_var_poss_list vars_term_list_var_poss_list)
    from source_at_pq have "source A |_ (p @ ?pi) = source ((to_pterm (lhs \<alpha>)) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>)|_?pi"
      using lhs_subst by (metis a p q subt_at_append subt_at_ctxt_of_pos_term)
    also have "... = Var ((var_rule \<alpha>)!i) \<cdot> \<langle>map source As\<rangle>\<^sub>\<alpha>"
      using subt_at_subst *
      by (metis (no_types, lifting) fun_mk_subst i nth_mem source.simps(1) source_apply_subst source_to_pterm to_pterm_wf_pterm var_poss_imp_poss var_poss_list_sound)
    also have "... = source (As!i)"
      unfolding eval_term.simps using i lhs_subst_var_i l2 by (metis (no_types, lifting) length_map nth_map)
    finally have "source A |_ (p @ ?pi) = source (As!i)" .
  }
  with l2 show ?thesis
    unfolding delta ll_single_redex_def by (simp add: map_eq_conv')
qed

lemma residual:
  shows "A re \<Delta> = Some ((ctxt_of_pos_term q A)\<langle>(to_pterm (rhs \<alpha>)) \<cdot> \<sigma>\<rangle>)"
proof-
  have l:"length (map2 (re) As (map (to_pterm \<circ> source) As)) = length As"
    by simp
  {fix i assume i:"i < length As"
    with as_well have "As!i re (to_pterm \<circ> source) (As!i) = Some (As!i)"
      by (metis comp_apply res_empty2)
    then have "map2 (re) As (map (to_pterm \<circ> source) As) ! i = Some (As ! i)"
      using i by force
  }
  then have *:"those (map2 (re) As (map (to_pterm \<circ> source) As)) = Some As"
    using those_some[OF l] using l by presburger
  from is_fun_lhs obtain f As' where f:"(to_pterm (lhs \<alpha>) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>) = Pfun f As'"
    by fastforce
  then have match:"match (Pfun f As') (to_pterm (lhs \<alpha>)) = Some (\<langle>As\<rangle>\<^sub>\<alpha>)"
    by (metis lhs_subst_trivial)
  have map:"map (\<langle>As\<rangle>\<^sub>\<alpha>) (var_rule \<alpha>) = As"
    using apply_lhs_subst_var_rule length_map by blast
  have "((to_pterm (lhs \<alpha>)) \<cdot> \<sigma>) re (Prule \<alpha> (map (to_pterm \<circ> source) As)) = Some ((to_pterm (rhs \<alpha>)) \<cdot> \<sigma>)"
    unfolding rhs_subst lhs_subst using residual.simps(7)[of f As' \<alpha> "(map (to_pterm \<circ> source) As)"]
    unfolding match f using * map by (metis option.simps(5))
  moreover from single_redex_pterm have "\<Delta> = (to_pterm_ctxt (source_ctxt (ctxt_of_pos_term q A)))\<langle>(Prule \<alpha> (map (to_pterm \<circ> source) As))\<rangle>"
    unfolding delta ll_single_redex_def pq[symmetric] by (simp add: p to_pterm_ctxt_at_pos)
  ultimately show ?thesis
    using a residual_op.apply_f_ctxt by (metis (no_types, lifting) ctxt_of_pos_term_well single_redex'_axioms single_redex'_def)
qed

end

end