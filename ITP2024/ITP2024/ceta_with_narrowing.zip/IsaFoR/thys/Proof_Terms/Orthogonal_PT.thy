(*
Author:  Christina Kohl <christina.kohl@uibk.ac.at> (2022)
License: LGPL (see file COPYING.LESSER)
*)
theory Orthogonal_PT
imports
  Residual_Join_Deletion
begin

inductive orthogonal::"('f, 'v) pterm \<Rightarrow> ('f, 'v) pterm \<Rightarrow> bool" (infixl "\<bottom>\<^sub>p" 50)
  where
  "Var x \<bottom>\<^sub>p Var x"
| "length As = length Bs \<Longrightarrow> \<forall> i < length As. As!i \<bottom>\<^sub>p Bs!i \<Longrightarrow> Pfun f As \<bottom>\<^sub>p Pfun f Bs"
| "length As = length Bs \<Longrightarrow> \<forall>(a,b) \<in> set(zip As Bs). a \<bottom>\<^sub>p b \<Longrightarrow> (Prule \<alpha> As) \<bottom>\<^sub>p (to_pterm (lhs \<alpha>)) \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha>"
| "length As = length Bs \<Longrightarrow> \<forall>(a,b) \<in> set(zip As Bs). a \<bottom>\<^sub>p b \<Longrightarrow> (to_pterm (lhs \<alpha>)) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha> \<bottom>\<^sub>p (Prule \<alpha> Bs)"
lemmas orthogonal.intros[intro]

lemma orth_symp: "symp (\<bottom>\<^sub>p)"
proof
  {fix A B::"('f, 'v) pterm" assume "A \<bottom>\<^sub>p B"
    then show "B \<bottom>\<^sub>p A" proof(induct)
      case (3 As Bs \<alpha>)
      then show ?case using orthogonal.intros(4)[where \<alpha>=\<alpha> and Bs=As and As=Bs]
        using zip_symm by fastforce
    next
      case (4 As Bs \<alpha>)
      then show ?case  using orthogonal.intros(3)[where \<alpha>=\<alpha> and As=Bs and Bs=As]
        using zip_symm by fastforce
    qed (simp_all add:orthogonal.intros)
  }
qed

lemma source_orthogonal:
  assumes "source A = t"
  shows "A \<bottom>\<^sub>p to_pterm t"
  using assms proof(induct A arbitrary:t)
  case (Prule \<alpha> As)
  then have t:"to_pterm t = (to_pterm (lhs \<alpha>)) \<cdot> \<langle>map (to_pterm \<circ> source) As\<rangle>\<^sub>\<alpha>"
    by (metis fun_mk_subst list.map_comp source.simps(3) to_pterm.simps(1) to_pterm_subst)
  from Prule(1) have "\<forall>(a,b) \<in> set (zip As (map (to_pterm \<circ> source) As)). a \<bottom>\<^sub>p b"
    by (metis (mono_tags, lifting) case_prod_beta' comp_def in_set_zip nth_map zip_fst)
  with t show ?case
    using orthogonal.intros(3) by (metis length_map)
qed (simp_all add:orthogonal.intros)

lemma orth_imp_co_initial:
  assumes "A \<bottom>\<^sub>p B"
  shows "co_initial A B"
using assms proof(induct rule: orthogonal.induct)
  case (3 As Bs \<alpha>)
  then have l:"length (zip As Bs) = length As"
    by simp
  with 3 have IH:"\<forall>i < length As. source (As!i) = source (Bs!i)"
    by (metis (mono_tags, lifting) case_prod_conv nth_mem nth_zip)
  have src:"source ((to_pterm (lhs \<alpha>)) \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha>) = (lhs \<alpha>) \<cdot> \<langle>map source Bs\<rangle>\<^sub>\<alpha>"
    by (simp add: source_apply_subst)
  from 3(1) l IH show ?case unfolding src source.simps
    by (metis nth_map_conv)
next
  case (4 As Bs \<alpha>)
  then have l:"length (zip As Bs) = length As"
    by simp
  with 4 have IH:"\<forall>i < length As. source (As!i) = source (Bs!i)"
    by (metis (mono_tags, lifting) case_prod_conv nth_mem nth_zip)
  have src:"source ((to_pterm (lhs \<alpha>)) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>) = (lhs \<alpha>) \<cdot> \<langle>map source As\<rangle>\<^sub>\<alpha>"
    by (simp add: source_apply_subst)
  from 4(1) l IH show ?case unfolding src source.simps
    by (metis nth_map_conv)
qed (simp_all add: map_eq_conv')

lemma var_orth_var_lhs:
  assumes "Var x \<bottom>\<^sub>p B"
  shows "Var x \<bottom>\<^sub>p Prule (Rule (Var y) t) (B#Bs)"
proof-
  let ?\<alpha> = "Rule (Var y) t"
  have "\<forall> i < length Bs. to_pterm (source (Bs!i)) \<bottom>\<^sub>p Bs!i"
    using source_orthogonal orth_symp sympD by fastforce
  then have *:"\<forall> (a,b) \<in> set (zip (Var x # (map (to_pterm\<circ>source) Bs)) (B#Bs)). a \<bottom>\<^sub>p b"
    using assms by (smt case_prodI comp_apply in_set_zip list.inject list.set_cases nth_map split_beta zip_Cons_Cons)
  have "Var x = to_pterm (lhs ?\<alpha>) \<cdot> \<langle>Var x # (map (to_pterm\<circ>source) Bs)\<rangle>\<^sub>?\<alpha>"
    unfolding lhs_def mk_subst_def
    by (metis (no_types, lifting) map_of_Cons_code(2) option.case(2) prule.simps(2) single_var eval_term.simps(1) to_pterm.simps(1) zip_Cons_Cons)
  then show ?thesis using assms orthogonal.intros(4)[where As="Var x # (map (to_pterm\<circ>source) Bs)" and Bs="B#Bs"] *
    by (metis length_map length_nth_simps(2))
qed

text\<open>If two proof terms are orthogonal then residual and join are well-defined.\<close>
lemma orth_imp_residual_defined:
  assumes varcond:"\<And>l r. (l, r) \<in> R \<Longrightarrow> is_Fun l" "\<And>l r. (l, r) \<in> S \<Longrightarrow> is_Fun l"
    and "A \<bottom>\<^sub>p B"
    and "A \<in> wf_pterm R" and "B \<in> wf_pterm S"
  shows "A re B \<noteq> None"
  using assms(3-) proof(induct)
  case (2 As Bs f)
  from 2(3) have wellAs:"\<forall>a \<in> set As. a \<in> wf_pterm R"
    by blast
  from 2(4) have wellBs:"\<forall>b \<in> set Bs. b \<in> wf_pterm S"
    by blast
  from 2(1,2) wellAs wellBs  have c:"\<forall>i < length As. (\<exists>C. As!i re Bs!i = Some C)"
    by auto
  from 2(1) have l:"length As = length (map2 (re) As Bs)"
    by simp
  from 2(1) have "\<forall>i < length As. As!i re Bs!i = (map2 (re) As Bs)!i"
    by simp
  with c obtain Cs where "\<forall>i < length As. As!i re Bs!i = Some (Cs!i)" and "length Cs = length As"
    using exists_some_list l by (metis (no_types, lifting))
  with 2 have "those (map2 (re) As Bs) = Some Cs"
    by (simp add: those_some)
  with 2 show ?case
    by simp
next
  case (3 As Bs \<alpha>)
  from 3(3) varcond obtain g ts where g:"lhs \<alpha> = Fun g ts"
    by (metis Inl_inject is_Fun_Fun_conv sum.simps(4) term.distinct(1) term.sel(2) wf_pterm.cases)
  then have *:"to_pterm (lhs \<alpha>) \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha> = Pfun g (map (\<lambda>t. t \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha>) (map to_pterm ts))"
    by simp
  from 3(3) have l1:"length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  from 3(3) have wellAs:"\<forall>a \<in> set As. a \<in> wf_pterm R"
    by blast
  from 3(1,4) l1 have wellBs:"\<forall>b \<in> set Bs. b \<in> wf_pterm S"
    by (simp add: lhs_subst_args_wf_pterm)
  from 3(1) have l2:"length (zip As Bs) = length As"
    by simp
  with 3(1,2) wellAs wellBs have "\<forall>i < length As. As ! i re Bs ! i \<noteq> None"
    by (metis (mono_tags, lifting) case_prod_conv nth_mem nth_zip)
  then have c:"\<forall>i < length As. (\<exists>C. As!i re Bs!i = Some C)"
    by blast
  from 3(1) have "\<forall>i < length As. As!i re Bs!i = (map2 (re) As Bs)!i"
    by simp
  with c obtain Cs where "\<forall>i < length As. As!i re Bs!i = Some (Cs!i)" and "length Cs = length As"
    using exists_some_list l2 by (metis (no_types, lifting) length_map)
  with 3 have cs:"those (map2 (re) As Bs) = Some Cs"
    by (simp add: those_some)
  have bs:"match (to_pterm (lhs \<alpha>) \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha>) (to_pterm (lhs \<alpha>)) = Some (\<langle>Bs\<rangle>\<^sub>\<alpha>)"
    using lhs_subst_trivial by blast
  then have "(map (\<langle>Bs\<rangle>\<^sub>\<alpha>) (var_rule \<alpha>)) = Bs"
    using 3(1) l1 apply_lhs_subst_var_rule by force
  then show ?case using residual.simps(5) using bs cs g unfolding *
    by simp
next
  case (4 As Bs \<alpha>)
  from 4(4) varcond obtain g ts where g:"lhs \<alpha> = Fun g ts"
    by (metis Inl_inject is_Fun_Fun_conv sum.simps(4) term.distinct(1) term.sel(2) wf_pterm.cases)
  then have *:"to_pterm (lhs \<alpha>) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha> = Pfun g (map (\<lambda>t. t \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>) (map to_pterm ts))"
    by simp
  from 4(4) have l1:"length Bs = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  from 4(1,3) l1 have wellAs:"\<forall>a \<in> set As. a \<in> wf_pterm R"
    by (simp add: lhs_subst_args_wf_pterm)
  from 4(4)  have wellBs:"\<forall>b \<in> set Bs. b \<in> wf_pterm S"
    by blast
  from 4(1) have l2:"length (zip As Bs) = length As"
    by simp
  with 4(1,2) wellAs wellBs have "\<forall>i < length As. As ! i re Bs ! i \<noteq> None"
    by (metis (mono_tags, lifting) case_prod_conv nth_mem nth_zip)
  then have c:"\<forall>i < length As. (\<exists>C. As!i re Bs!i = Some C)"
    by blast
  from 4(1) have "\<forall>i < length As. As!i re Bs!i = (map2 (re) As Bs)!i"
    by simp
  with c obtain Cs where "\<forall>i < length As. As!i re Bs!i = Some (Cs!i)" and "length Cs = length As"
    using exists_some_list l2 by (metis (no_types, lifting) length_map)
  with 4 have cs:"those (map2 (re) As Bs) = Some Cs"
    by (simp add: those_some)
  have bs:"match (to_pterm (lhs \<alpha>) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>) (to_pterm (lhs \<alpha>)) = Some (\<langle>As\<rangle>\<^sub>\<alpha>)"
    using lhs_subst_trivial by blast
  have "(map (\<langle>As\<rangle>\<^sub>\<alpha>) (var_rule \<alpha>)) = As"
    using 4(1) l1 apply_lhs_subst_var_rule by force
  then show ?case using residual.simps(7) using bs cs g unfolding *
    by simp
qed simp

(*The proof is almost word for word copied from orth_imp_residual_defined. Can this be combined?*)
lemma orth_imp_join_defined:
  assumes varcond:"\<And>l r. (l, r) \<in> R \<Longrightarrow> is_Fun l"
    and "A \<bottom>\<^sub>p B"
    and "A \<in> wf_pterm R" and "B \<in> wf_pterm R"
  shows "A \<squnion> B \<noteq> None"
  using assms(2-) proof(induct)
  case (2 As Bs f)
  from 2(3) have wellAs:"\<forall>a \<in> set As. a \<in> wf_pterm R"
    by blast
  from 2(4) have wellBs:"\<forall>b \<in> set Bs. b \<in> wf_pterm R"
    by blast
  from 2(1,2) wellAs wellBs  have c:"\<forall>i < length As. (\<exists>C. As!i \<squnion> Bs!i = Some C)"
    by auto
  from 2(1) have l:"length As = length (map2 (\<squnion>) As Bs)"
    by simp
  from 2(1) have "\<forall>i < length As. As!i \<squnion> Bs!i = (map2 (\<squnion>) As Bs)!i"
    by simp
  with c obtain Cs where "\<forall>i < length As. As!i \<squnion> Bs!i = Some (Cs!i)" and "length Cs = length As"
    using exists_some_list l by (metis (no_types, lifting))
  with 2 have "those (map2 (\<squnion>) As Bs) = Some Cs"
    by (simp add: those_some)
  with 2 show ?case
    by simp
next
  case (3 As Bs \<alpha>)
  from 3(3) varcond obtain g ts where g:"lhs \<alpha> = Fun g ts"
    by (metis Inl_inject is_Fun_Fun_conv sum.simps(4) term.distinct(1) term.sel(2) wf_pterm.cases)
  then have *:"to_pterm (lhs \<alpha>) \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha> = Pfun g (map (\<lambda>t. t \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha>) (map to_pterm ts))"
    by simp
  from 3(3) have l1:"length As = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  from 3(3) have wellAs:"\<forall>a \<in> set As. a \<in> wf_pterm R"
    by blast
  from 3(1,4) l1 have wellBs:"\<forall>b \<in> set Bs. b \<in> wf_pterm R"
    by (simp add: lhs_subst_args_wf_pterm)
  from 3(1) have l2:"length (zip As Bs) = length As"
    by simp
  with 3(1,2) wellAs wellBs have "\<forall>i < length As. As ! i \<squnion> Bs ! i \<noteq> None"
    by (metis (mono_tags, lifting) case_prod_conv nth_mem nth_zip)
  then have c:"\<forall>i < length As. (\<exists>C. As!i \<squnion> Bs!i = Some C)"
    by blast
  from 3(1) have "\<forall>i < length As. As!i \<squnion> Bs!i = (map2 (\<squnion>) As Bs)!i"
    by simp
  with c obtain Cs where "\<forall>i < length As. As!i \<squnion> Bs!i = Some (Cs!i)" and "length Cs = length As"
    using exists_some_list l2 by (metis (no_types, lifting) length_map)
  with 3 have cs:"those (map2 (\<squnion>) As Bs) = Some Cs"
    by (simp add: those_some)
  have bs:"match (to_pterm (lhs \<alpha>) \<cdot> \<langle>Bs\<rangle>\<^sub>\<alpha>) (to_pterm (lhs \<alpha>)) = Some (\<langle>Bs\<rangle>\<^sub>\<alpha>)"
    using lhs_subst_trivial by blast
  then have "(map (\<langle>Bs\<rangle>\<^sub>\<alpha>) (var_rule \<alpha>)) = Bs"
    using 3(1) l1 apply_lhs_subst_var_rule by force
  then show ?case using residual.simps(5) using bs cs g unfolding *
    by simp
next
  case (4 As Bs \<alpha>)
  from 4(4) varcond obtain g ts where g:"lhs \<alpha> = Fun g ts"
    by (metis Inl_inject is_Fun_Fun_conv sum.simps(4) term.distinct(1) term.sel(2) wf_pterm.cases)
  then have *:"to_pterm (lhs \<alpha>) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha> = Pfun g (map (\<lambda>t. t \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>) (map to_pterm ts))"
    by simp
  from 4(4) have l1:"length Bs = length (var_rule \<alpha>)"
    using wf_pterm.simps by fastforce
  from 4(1,3) l1 have wellAs:"\<forall>a \<in> set As. a \<in> wf_pterm R"
    by (simp add: lhs_subst_args_wf_pterm)
  from 4(4)  have wellBs:"\<forall>b \<in> set Bs. b \<in> wf_pterm R"
    by blast
  from 4(1) have l2:"length (zip As Bs) = length As"
    by simp
  with 4(1,2) wellAs wellBs have "\<forall>i < length As. As ! i \<squnion> Bs ! i \<noteq> None"
    by (metis (mono_tags, lifting) case_prod_conv nth_mem nth_zip)
  then have c:"\<forall>i < length As. (\<exists>C. As!i \<squnion> Bs!i = Some C)"
    by blast
  from 4(1) have "\<forall>i < length As. As!i \<squnion> Bs!i = (map2 (\<squnion>) As Bs)!i"
    by simp
  with c obtain Cs where "\<forall>i < length As. As!i \<squnion> Bs!i = Some (Cs!i)" and "length Cs = length As"
    using exists_some_list l2 by (metis (no_types, lifting) length_map)
  with 4 have cs:"those (map2 (\<squnion>) As Bs) = Some Cs"
    by (simp add: those_some)
  have bs:"match (to_pterm (lhs \<alpha>) \<cdot> \<langle>As\<rangle>\<^sub>\<alpha>) (to_pterm (lhs \<alpha>)) = Some (\<langle>As\<rangle>\<^sub>\<alpha>)"
    using lhs_subst_trivial by blast
  have "(map (\<langle>As\<rangle>\<^sub>\<alpha>) (var_rule \<alpha>)) = As"
    using 4(1) l1 apply_lhs_subst_var_rule by force
  then show ?case using residual.simps(7) using bs cs g unfolding *
    by simp
qed simp

end
