(* Automatically generated file, do not change *)
theory All_of_Proof_Terms
  imports
    Labels_and_Overlaps
    Orthogonal_PT
    Proof_Terms
    Residual_Join_Deletion
    Utils
begin
end
