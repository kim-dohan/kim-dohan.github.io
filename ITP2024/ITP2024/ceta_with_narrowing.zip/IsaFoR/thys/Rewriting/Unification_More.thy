(*
Author:  Christian Sternagel <c.sternagel@gmail.com> (2013-2015, 2017)
Author:  René Thiemann <rene.thiemann@uibk.ac.at> (2014, 2015)
License: LGPL (see file COPYING.LESSER)
*)

section \<open>A Concrete Unification Algorithm\<close>

theory Unification_More
  imports
    First_Order_Terms.Unification
    Term_Impl
begin

hide_const (open) FuncSet.compose

lemma set_subst_list [simp]:
  "set (subst_list \<sigma> E) = subst_set \<sigma> (set E)"
  by (simp add: subst_list_def subst_set_def)

lemma mgu_var_disjoint_right:
  fixes s t :: "('f, 'v) term" and \<sigma> \<tau> :: "('f, 'v) subst" and T 
  assumes s: "vars_term s \<subseteq> S"
    and inj: "inj T"
    and ST: "S \<inter> range T = {}"
    and id: "s \<cdot> \<sigma> = t \<cdot> \<tau>"
  shows "\<exists> \<mu> \<delta>. mgu s (map_vars_term T t) = Some \<mu> \<and>
    s \<cdot> \<sigma> = s \<cdot> \<mu> \<cdot> \<delta> \<and>
    (\<forall>t::('f, 'v) term. t \<cdot> \<tau> = map_vars_term T t \<cdot> \<mu> \<cdot> \<delta>) \<and>
    (\<forall>x\<in>S. \<sigma> x = \<mu> x \<cdot> \<delta>)"
proof -
  let ?\<sigma> = "\<lambda> x. if x \<in> S then \<sigma> x else \<tau> ((the_inv T) x)"
  let ?t = "map_vars_term T t"
  have ids: "s \<cdot> \<sigma> = s \<cdot> ?\<sigma>"
    by (rule term_subst_eq, insert s, auto)
  have "t \<cdot> \<tau> = map_vars_term (the_inv T) ?t \<cdot> \<tau>"
    unfolding map_vars_term_compose o_def using the_inv_f_f[OF inj] by (auto simp: term.map_ident)
  also have "... = ?t \<cdot> (\<tau> \<circ> the_inv T)" unfolding apply_subst_map_vars_term ..
  also have "... = ?t \<cdot> ?\<sigma>"
  proof (rule term_subst_eq)
    fix x
    assume "x \<in> vars_term ?t"
    then have "x \<in> T ` UNIV" unfolding term.set_map by auto
    then have "x \<notin> S" using ST by auto
    then show "(\<tau> \<circ> the_inv T) x = ?\<sigma> x" by simp
  qed
  finally have idt: "t \<cdot> \<tau> = ?t \<cdot> ?\<sigma>" by simp
  from id[unfolded ids idt] have id: "s \<cdot> ?\<sigma> = ?t \<cdot> ?\<sigma>" .
  with mgu_complete[of s ?t] id obtain \<mu> where \<mu>: "mgu s ?t = Some \<mu>"
    unfolding unifiers_def  by (cases "mgu s ?t", auto)
  from the_mgu[OF id] have id: "s \<cdot> \<mu> = map_vars_term T t \<cdot> \<mu>" and \<sigma>: "?\<sigma> = \<mu> \<circ>\<^sub>s ?\<sigma>"
    unfolding the_mgu_def \<mu> by auto
  have "s \<cdot> \<sigma> = s \<cdot> (\<mu> \<circ>\<^sub>s ?\<sigma>)" unfolding ids using \<sigma> by simp
  also have "... = s \<cdot> \<mu> \<cdot> ?\<sigma>" by simp
  finally have ids: "s \<cdot> \<sigma> = s \<cdot> \<mu> \<cdot> ?\<sigma>" .
  {
    fix x
    have "\<tau> x = ?\<sigma> (T x)" using ST unfolding the_inv_f_f[OF inj] by auto
    also have "... = (\<mu> \<circ>\<^sub>s ?\<sigma>) (T x)" using \<sigma> by simp
    also have "... = \<mu> (T x) \<cdot> ?\<sigma>" unfolding subst_compose_def by simp
    finally have "\<tau> x = \<mu> (T x) \<cdot> ?\<sigma>" .
  } note \<tau> = this
  {
    fix t :: "('f,'v)term"
    have "t \<cdot> \<tau> = t \<cdot> (\<lambda> x. \<mu> (T x) \<cdot> ?\<sigma>)" unfolding \<tau>[symmetric] ..
    also have "... = map_vars_term T t \<cdot> \<mu> \<cdot> ?\<sigma>" unfolding apply_subst_map_vars_term 
      subst_subst by (rule term_subst_eq, simp add: subst_compose_def)
    finally have "t \<cdot> \<tau> = map_vars_term T t \<cdot> \<mu> \<cdot> ?\<sigma>" .
  } note idt = this
  {
    fix x 
    assume "x \<in> S"
    then have "\<sigma> x = ?\<sigma> x" by simp
    also have "... = (\<mu> \<circ>\<^sub>s ?\<sigma>) x" using \<sigma> by simp
    also have "... = \<mu> x \<cdot> ?\<sigma>" unfolding subst_compose_def ..
    finally have "\<sigma> x = \<mu> x \<cdot> ?\<sigma>" .
  } note \<sigma> = this
  show ?thesis 
    by (rule exI[of _ \<mu>], rule exI[of _ ?\<sigma>], insert \<mu> ids idt \<sigma>, auto)
qed


abbreviation (input) x_var :: "string \<Rightarrow> string" where "x_var \<equiv> Cons (CHR ''x'')"
abbreviation (input) y_var :: "string \<Rightarrow> string" where "y_var \<equiv> Cons (CHR ''y'')"
abbreviation (input) z_var :: "string \<Rightarrow> string" where "z_var \<equiv> Cons (CHR ''z'')"

lemma mgu_var_disjoint_right_string:
  fixes s t :: "('f, string) term" and \<sigma> \<tau> :: "('f, string) subst"
  assumes s: "vars_term s \<subseteq> range x_var \<union> range z_var"
    and id: "s \<cdot> \<sigma> = t \<cdot> \<tau>"
  shows "\<exists> \<mu> \<delta>. mgu s (map_vars_term y_var t) = Some \<mu> \<and>
    s \<cdot> \<sigma> = s \<cdot> \<mu> \<cdot> \<delta> \<and> (\<forall>t::('f, string) term. t \<cdot> \<tau> = map_vars_term y_var t \<cdot> \<mu> \<cdot> \<delta>) \<and>
    (\<forall>x \<in> range x_var \<union> range z_var. \<sigma> x = \<mu> x \<cdot> \<delta>)"
proof -
  have inj: "inj y_var" unfolding inj_on_def by simp
  show ?thesis
    by (rule mgu_var_disjoint_right[OF s inj _ id], auto)
qed

lemma not_elem_subst_of:
  assumes "x \<notin> set (map fst xs)"
  shows "(subst_of xs) x = Var x"
  using assms proof (induct xs)
  case (Cons y xs)
  then show ?case unfolding subst_of_simps
    by (metis Term.term.simps(17) insert_iff list.simps(15) list.simps(9) singletonD subst_compose subst_ident)
qed simp

(*The variable x is mapped to term t if (x, t) appears in the list given to subst_of
and no variable of t is bound to another value by the constructed substitution.*)
lemma subst_of_apply:
  assumes "(x, t) \<in> set ss"
    and "\<forall>(y,s) \<in> set ss. (y = x \<longrightarrow> s = t)"
    and "set (map fst ss) \<inter> vars_term t = {}"
  shows "subst_of ss x = t"
  using assms proof(induct ss)
  case (Cons a ss)
  show ?case proof(cases "(x,t) \<in> set ss")
    case True
    from Cons(1)[OF True] Cons(3,4) have sub:"subst_of ss x = t"
      by (simp add: disjoint_iff) 
    from Cons(2,4) have "fst a \<notin> vars_term t"
      by fastforce 
    then show ?thesis 
      unfolding subst_of_simps subst_compose sub by simp 
  next
    case False
    then have "x \<notin> set (map fst ss)"
      using Cons(3) by auto
    then have sub:"subst_of ss x = Var x"
      by (meson not_elem_subst_of) 
    from Cons(2) False have "a = (x, t)"
      by simp 
    then show ?thesis 
      unfolding subst_of_simps subst_compose sub by simp 
  qed
qed simp

(*If every variable appears only once on the left or on the right of 
list of pairs given to subst_of, then the order in which the pairs are 
processed does not matter.*)
lemma subst_of_partition:
  assumes "set substs = set res"
    and "is_partition ((map ((\<lambda>x. {x}) \<circ> fst) res) @ (map (vars_term \<circ> snd) res))"
  shows "subst_of substs = subst_of res"
proof-
  {fix x
    have "subst_of substs x = subst_of res x" proof(cases "x \<in> set (map fst res)")
      case True
      then obtain t where t:"(x,t) \<in> set res"
        by auto 
      moreover have unique:"\<forall>(y,s) \<in> set res. (y = x \<longrightarrow> s = t)" proof-
        {fix s assume s:"(x, s) \<in> set res" "s \<noteq> t"
          from assms(2) have "is_partition (map ((\<lambda>x. {x}) \<circ> fst) res)"
            by (metis append_Nil is_partition_sublist) 
          moreover from t obtain i where i:"res!i = (x,t)" "i < length res"
            by (metis in_set_idx) 
          moreover with s obtain j where j:"res!j = (x,s)" "j < length res" "i \<noteq> j"
            by (metis Pair_inject in_set_idx) 
          ultimately have False
            by (metis (mono_tags, lifting) IntI comp_apply empty_iff fst_conv is_partition_alt is_partition_alt_def length_map nth_map singletonI) 
        }
        then show ?thesis  by blast 
      qed
      moreover have disjoint:"set (map fst res) \<inter> vars_term t = {}" 
      proof-
        from t have "vars_term t \<in> set (map (vars_term \<circ> snd) res)"
          by (metis (mono_tags, opaque_lifting) image_eqI list.set_map o_apply prod.sel(2)) 
        then have "\<forall>i<length (map ((\<lambda>x. {x}) \<circ> fst) res). map ((\<lambda>x. {x}) \<circ> fst) res ! i \<inter> (vars_term t) = {}" 
          using is_partition_intersection[OF assms(2)] by blast
        then have "\<forall>x. x \<in> set (map fst res) \<longrightarrow> {x} \<inter> vars_term t = {}"
          by (metis (no_types, lifting) in_set_conv_nth length_map list.map_comp map_nth_eq_conv)
        then show ?thesis 
          using disjoint_iff by blast 
      qed
      ultimately have resx:"subst_of res x = t"
        by (simp add: subst_of_apply)
      from t have "(x,t) \<in> set substs" 
        using assms(1) by simp 
      moreover have "\<forall>(y,s) \<in> set substs. (y = x \<longrightarrow> s = t)" 
        using assms(1) unique by presburger  
      moreover have "set (map fst substs) \<inter> vars_term t = {}" 
        using assms(1) disjoint by simp 
      ultimately have "subst_of substs x = t"
        by (simp add: subst_of_apply)
      with resx show ?thesis
        by simp  
    next
      case False
      with assms(1) show ?thesis by (simp add: not_elem_subst_of)
    qed
  }
  then show ?thesis
    by blast 
qed

section\<open>Unification of linear and variable disjoint terms\<close>

(*Substitutions from variable positions of term on the left to subterms of term on the right.*)
definition left_substs :: "('f, 'v) term \<Rightarrow> ('f, 'v) term \<Rightarrow> ('v \<times> ('f, 'v) term) list"
  where "left_substs s t = (let filtered_vars = filter (\<lambda>(_, p). p \<in> poss t) (zip (vars_term_list s)(var_poss_list s))
          in map (\<lambda>(x, p). (x, t|_p)) filtered_vars)"

(*Substitutions from variable positions of term on the right to subterms of the term on the left. 
Almost symmetric definition to the one above. Difference is that if there is a variable x at position
p on the left and a variable y at the same position on the right then we don't add mapping y \<mapsto> x!.*)
definition right_substs :: "('f, 'v) term \<Rightarrow> ('f, 'v) term \<Rightarrow> ('v \<times> ('f, 'v) term) list"
  where "right_substs s t = (let filtered_vars = filter (\<lambda>(_, q). q \<in> fun_poss s) (zip (vars_term_list t)(var_poss_list t))
          in map (\<lambda>(y, q). (y, s|_q)) filtered_vars)"

lemma left_substs_imp_props:
  assumes "(x, u) \<in> set (left_substs s t)"
  shows "\<exists>p. p \<in> poss s \<and> s|_p = Var x \<and> p \<in> poss t \<and> t|_p = u"
proof-
  from assms obtain p where 1:"(x, p) \<in> set (zip (vars_term_list s)(var_poss_list s))" and 2:"p \<in> poss t" "t|_p = u"
    unfolding left_substs_def Let_def using Pair_inject case_prodE filter_set in_set_idx length_map map_nth_eq_conv member_filter nth_mem old.prod.case by auto 
  from 1 have p:"p \<in> poss s"
    by (metis set_zip_rightD var_poss_imp_poss var_poss_list_sound) 
  from 1 obtain i where "i < length (zip (vars_term_list s)(var_poss_list s))" and "(vars_term_list s)!i = x" and "(var_poss_list s)!i = p"
    by (smt (z3) Pair_inject length_zip mem_Collect_eq set_zip)
  then have "s|_p = Var x"
    by (metis length_zip min_less_iff_conj vars_term_list_var_poss_list)
  with 2 p show ?thesis
    by blast 
qed

lemma props_imp_left_substs:
  assumes "p \<in> poss s" and "s|_p = Var x" and "p \<in> poss t" and "t|_p = u"
  shows "(x, u) \<in> set (left_substs s t)"
proof-
  from assms obtain i where "(var_poss_list s)!i = p" and "(vars_term_list s)!i = x"
    by (metis in_set_conv_nth length_var_poss_list term.inject(1) var_poss_iff var_poss_list_sound vars_term_list_var_poss_list) 
  then have "(x, p) \<in> set (zip (vars_term_list s)(var_poss_list s))"
    by (metis assms(1) assms(2) in_set_idx in_set_zip length_var_poss_list prod.sel(1) prod.sel(2) term.inject(1) var_poss_iff var_poss_list_sound vars_term_list_var_poss_list)
  with assms(3) have "(x, p) \<in> set (filter (\<lambda>(_, p). p \<in> poss t) (zip (vars_term_list s) (var_poss_list s)))"
    by simp 
  then show ?thesis unfolding left_substs_def Let_def assms(4)[symmetric] 
    by (smt (z3) case_prod_conv in_set_conv_nth length_map map_nth_eq_conv)
qed

lemma right_substs_imp_props:
  assumes "(x, u) \<in> set (right_substs s t)"
  shows "\<exists>q. q \<in> fun_poss s \<and> s|_q = u \<and> q \<in> poss t \<and> t|_q = Var x"
proof-
  from assms obtain q where 1:"(x, q) \<in> set (zip (vars_term_list t)(var_poss_list t))" and 2:"q \<in> fun_poss s" "s|_q = u"
    unfolding right_substs_def Let_def using Pair_inject case_prodE filter_set in_set_idx length_map map_nth_eq_conv member_filter nth_mem old.prod.case by auto 
  from 1 have q:"q \<in> poss t"
    by (metis set_zip_rightD var_poss_imp_poss var_poss_list_sound)
  from 1 obtain i where "i < length (zip (vars_term_list t)(var_poss_list t))" and "(vars_term_list t)!i = x" and "(var_poss_list t)!i = q"
    by (smt (z3) Pair_inject length_zip mem_Collect_eq set_zip)
  then have "t|_q = Var x"
    by (metis length_zip min_less_iff_conj vars_term_list_var_poss_list)
  with 2 q show ?thesis 
    by blast 
qed

lemma props_imp_right_substs:
  assumes "q \<in> fun_poss s" and "s|_q = u" and "q \<in> poss t" and "t|_q = Var x"
  shows "(x, u) \<in> set (right_substs s t)"
proof-
  from assms obtain i where "(var_poss_list t)!i = q" and "(vars_term_list t)!i = x"
    by (metis in_set_conv_nth length_var_poss_list term.inject(1) var_poss_iff var_poss_list_sound vars_term_list_var_poss_list)  
  then have "(x, q) \<in> set (zip (vars_term_list t)(var_poss_list t))"
    by (metis assms(3) assms(4) in_set_conv_nth in_set_zip length_var_poss_list prod.sel(1) prod.sel(2) term.inject(1) var_poss_iff var_poss_list_sound vars_term_list_var_poss_list)
  with assms(1) have "(x, q) \<in> set (filter (\<lambda>(_, p). p \<in> fun_poss s) (zip (vars_term_list t) (var_poss_list t)))"
    by simp 
  then show ?thesis unfolding right_substs_def Let_def assms(2)[symmetric] 
    by (smt (z3) case_prod_conv in_set_conv_nth length_map map_nth_eq_conv)
qed

lemma map_fst_left_substs: 
  "set (map fst (left_substs s t)) \<subseteq> vars_term s" 
unfolding left_substs_def using zip_fst by fastforce

lemma map_snd_left_substs: 
  assumes "t' \<in> set (map snd (left_substs s t))"
  shows "vars_term t' \<subseteq> vars_term t" 
proof-
  from assms obtain x where "(x, t') \<in> set (left_substs s t)"
    by force 
  then show ?thesis 
    using left_substs_imp_props by (metis vars_term_subt_at)
qed

lemma map_snd_right_substs: 
  assumes "t' \<in> set (map snd (right_substs s t))"
  shows "vars_term t' \<subseteq> vars_term s" 
proof-
  from assms obtain x where "(x, t') \<in> set (right_substs s t)"
    by force 
  then show ?thesis 
    using right_substs_imp_props by (metis fun_poss_imp_poss vars_term_subt_at)
qed

lemma distinct_map_fst_left_substs:
  assumes "linear_term t"
  shows "distinct (map fst (left_substs t s))"
proof-
  from linear_term_distinct_vars[OF assms] have dist:"distinct (map fst (filter (\<lambda>(x, p). p \<in> poss s) (zip (vars_term_list t) (var_poss_list t))))"
    by (simp add: distinct_map_filter length_var_poss_list)
  have "map fst (left_substs t s) = (map fst (filter (\<lambda>(x, p). p \<in> poss s) (zip (vars_term_list t) (var_poss_list t))))" 
    unfolding left_substs_def Let_def by auto 
  with dist show ?thesis
    by presburger 
qed

lemma distinct_map_fst_right_substs:
  assumes "linear_term t"
  shows "distinct (map fst (right_substs s t))"
proof-
  from linear_term_distinct_vars[OF assms] have dist:"distinct (map fst (filter (\<lambda>(x, p). p \<in> fun_poss s) (zip (vars_term_list t) (var_poss_list t))))"
    by (simp add: distinct_map_filter length_var_poss_list)
  have "map fst (right_substs s t) = (map fst (filter (\<lambda>(x, p). p \<in> fun_poss s) (zip (vars_term_list t) (var_poss_list t))))" 
    unfolding right_substs_def Let_def by auto 
  with dist show ?thesis
    by presburger 
qed

lemma is_partition_map_snd_left_substs:
  assumes "linear_term s" "linear_term t"
  shows "is_partition (map (vars_term \<circ> snd) (left_substs t s))"
proof-
  {fix i j assume j:"j < length (left_substs t s)" and i:"i < j" 
    from i j obtain x u where xu:"(x, u) = (left_substs t s)!i"
      by (metis surj_pair) 
    from i j obtain y v where yv:"(y, v) = (left_substs t s)!j"
      by (metis surj_pair) 
    from xu i j obtain p where p:"p \<in> poss t"  "t|_p = Var x"  "p \<in> poss s"  "s|_p = u" 
      using left_substs_imp_props by (metis Suc_lessD less_trans_Suc nth_mem) 
    from yv i j obtain q where q:"q \<in> poss t"  "t|_q = Var y"  "q \<in> poss s"  "s|_q = v" 
      using left_substs_imp_props by (metis nth_mem) 
    from assms(2) have "distinct (map fst (left_substs t s))" 
      using distinct_map_fst_left_substs by blast
    with xu yv i j have "x \<noteq> y"
      by (metis (mono_tags, lifting) Suc_lessD distinct_map eq_key_imp_eq_value less_trans_Suc nat_neq_iff nth_eq_iff_index_eq nth_mem)  
    with p(1,2) q(1,2) have "p \<bottom> q"
      by (metis term.inject(1) var_poss_iff var_poss_parallel) 
    with assms(1) p(3,4) q(3,4) have "vars_term (snd ((left_substs t s)!i)) \<inter> vars_term (snd ((left_substs t s)!j)) = {}"
      by (metis linear_subterms_disjoint_vars snd_eqD xu yv) 
  }
  then show ?thesis unfolding is_partition_def map_map[symmetric] by auto  
qed

lemma is_partition_map_snd_right_substs:
  assumes "linear_term s" "linear_term t"
  shows "is_partition (map (vars_term \<circ> snd) (right_substs t s))"
proof-
  {fix i j assume j:"j < length (right_substs t s)" and i:"i < j" 
    from i j obtain x u where xu:"(x, u) = (right_substs t s)!i"
      by (metis surj_pair) 
    from i j obtain y v where yv:"(y, v) = (right_substs t s)!j"
      by (metis surj_pair) 
    from xu i j obtain p where p:"p \<in> poss s"  "s|_p = Var x"  "p \<in> fun_poss t"  "t|_p = u" 
      using right_substs_imp_props by (metis Suc_lessD less_trans_Suc nth_mem) 
    from yv i j obtain q where q:"q \<in> poss s"  "s|_q = Var y"  "q \<in> fun_poss t"  "t|_q = v" 
      using right_substs_imp_props by (metis nth_mem) 
    from assms(1) have "distinct (map fst (right_substs t s))" 
      using distinct_map_fst_right_substs by blast
    with xu yv i j have "x \<noteq> y"
      by (metis (mono_tags, lifting) Suc_lessD distinct_map eq_key_imp_eq_value less_trans_Suc nat_neq_iff nth_eq_iff_index_eq nth_mem)  
    with p(1,2) q(1,2) have "p \<bottom> q"
      by (metis term.inject(1) var_poss_iff var_poss_parallel) 
    with assms(2) p(3,4) q(3,4) have "vars_term (snd ((right_substs t s)!i)) \<inter> vars_term (snd ((right_substs t s)!j)) = {}"
      by (metis fun_poss_imp_poss linear_subterms_disjoint_vars snd_eqD xu yv) 
  }
  then show ?thesis unfolding is_partition_def map_map[symmetric] by auto  
qed

lemma distinct_fst_lsubsts_snd_rsubsts:
  assumes "linear_term s"
  shows "(set (map fst (left_substs s t))) \<inter> \<Union> (set (map (vars_term \<circ> snd) (right_substs s t))) = {}"
proof-
  {fix x u assume "(x,u) \<in> set (left_substs s t)"
    then obtain p where p:"p \<in> poss s" "s|_p = Var x" "p \<in> poss t"  "t|_p = u"
      by (meson left_substs_imp_props) 
    {fix y v assume "(y,v) \<in> set (right_substs s t)"
      then obtain q where q:"q \<in> poss t" "t|_q = Var y" "q \<in> fun_poss s"  "s|_q = v"
        by (meson right_substs_imp_props) 
      with p have "p \<bottom> q"
        by (metis Term.term.simps(4) append.right_neutral fun_poss_fun_conv fun_poss_imp_poss parallel_pos prefix_pos_diff var_pos_maximal)
      with assms p(1,2) q(3,4) have "x \<notin> vars_term v"
        using fun_poss_imp_poss linear_subterms_disjoint_vars by fastforce
    }
    then have "x \<notin> \<Union> (set (map (vars_term \<circ> snd) (right_substs s t)))"
      by fastforce
  }
  then show ?thesis by fastforce
qed

lemma distinct_fst_rsubsts_snd_lsubsts:
  assumes "linear_term t"
  shows "(set (map fst (right_substs s t))) \<inter> \<Union> (set (map (vars_term \<circ> snd) (left_substs s t))) = {}"
proof-
  {fix x u assume "(x,u) \<in> set (right_substs s t)"
    then obtain p where p:"p \<in> poss t" "t|_p = Var x" "p \<in> fun_poss s"  "s|_p = u"
      by (meson right_substs_imp_props) 
    {fix y v assume "(y,v) \<in> set (left_substs s t)"
      then obtain q where q:"q \<in> poss s" "s|_q = Var y" "q \<in> poss t"  "t|_q = v"
        by (meson left_substs_imp_props) 
      with p have "p \<bottom> q"
        by (metis Term.term.simps(4) append.right_neutral fun_poss_fun_conv fun_poss_imp_poss parallel_pos prefix_pos_diff var_pos_maximal)
      with assms p(1,2) q(3,4) have "x \<notin> vars_term v"
        using fun_poss_imp_poss linear_subterms_disjoint_vars by fastforce
    }
    then have "x \<notin> \<Union> (set (map (vars_term \<circ> snd) (left_substs s t)))"
      by fastforce
  }
  then show ?thesis by fastforce
qed

text\<open>connection between left_substs and right_substs and decomposition of functions\<close>
lemma decompose_left_substs:
  assumes "decompose (Fun f ss) (Fun g ts) = Some ds"
  shows "set (left_substs (Fun f ss) (Fun g ts)) = (\<Union>e\<in>set ds. set (left_substs (fst e) (snd e)))" (is "?left = ?right") 
proof
  from assms have ds:"ds = zip ss ts" 
    using decompose_Some by auto
  show "?left \<subseteq> ?right" proof
    fix x t assume "(x,t) \<in> set (left_substs (Fun f ss) (Fun g ts))"
    then obtain p where 1:"p \<in> poss (Fun f ss)" and 2:"(Fun f ss)|_p = Var x" and 3:"p \<in> poss (Fun g ts)" and 4:"(Fun g ts)|_p = t"
      by (meson left_substs_imp_props) 
    from 1 2 obtain j p' where j1:"j < length ss" and "p = j#p'" and "p' \<in> poss (ss!j)" and "(ss!j)|_p' = Var x"
      by auto 
    moreover with 3 4 have j2:"j < length ts" and "p' \<in> poss (ts!j)" and "(ts!j)|_p' = t" 
      by auto
    ultimately have "(x,t) \<in> set (left_substs (ss!j) (ts!j))"
      by (meson props_imp_left_substs)
    moreover have "((ss!j),(ts!j)) \<in> set ds" 
      unfolding ds using j1 j2 by (metis length_zip min_less_iff_conj nth_mem nth_zip) 
    ultimately show "(x,t) \<in> (\<Union>e\<in>set ds. set (left_substs (fst e) (snd e)))"
      by force    
  qed
  show "?right \<subseteq> ?left" proof
    fix x t assume "(x,t) \<in> (\<Union>e\<in>set ds. set (left_substs (fst e) (snd e)))"
    then obtain j where j1:"j < length ss" and j2:"j < length ts" and "(x,t) \<in> set (left_substs (ss!j) (ts!j))" 
      unfolding ds by (metis (no_types, lifting) UN_E in_set_zip) 
    then obtain p where 1:"p \<in> poss (ss!j)" and 2:"(ss!j)|_p = Var x" and 3:"p \<in> poss (ts!j)" and 4:"(ts!j)|_p = t"
      by (meson left_substs_imp_props)
    then have "j#p \<in> poss (Fun f ss)" and "(Fun f ss)|_(j#p) = Var x" and "(j#p) \<in> poss (Fun g ts)" and "(Fun g ts)|_(j#p) = t" 
      using j1 j2 by auto
    then show "(x,t) \<in> set (left_substs (Fun f ss) (Fun g ts))"
      by (meson props_imp_left_substs)
  qed
qed 

lemma decompose_right_substs:
  assumes "decompose (Fun f ss) (Fun g ts) = Some ds"
  shows "set (right_substs (Fun f ss) (Fun g ts)) = (\<Union>e\<in>set ds. set (right_substs (fst e) (snd e)))" (is "?left = ?right") 
proof
  from assms have ds:"ds = zip ss ts" 
    using decompose_Some by auto
  show "?left \<subseteq> ?right" proof
    fix x t assume "(x,t) \<in> set (right_substs (Fun f ss) (Fun g ts))"
    then obtain q where 1:"q \<in> fun_poss (Fun f ss)" and 2:"(Fun f ss)|_q = t" and 3:"q \<in> poss (Fun g ts)" and 4:"(Fun g ts)|_q = Var x"
      by (meson right_substs_imp_props) 
    from 3 4 obtain j q' where j1:"j < length ts" and "q = j#q'" and "q' \<in> poss (ts!j)" and "(ts!j)|_q' = Var x" 
      by auto 
    moreover with 1 2 have j2:"j < length ss" and "q' \<in> fun_poss (ss!j)" and "(ss!j)|_q' = t" 
      by auto
    ultimately have "(x,t) \<in> set (right_substs (ss!j) (ts!j))"
      by (meson props_imp_right_substs)
    moreover have "((ss!j),(ts!j)) \<in> set ds" 
      unfolding ds using j1 j2 by (metis length_zip min_less_iff_conj nth_mem nth_zip) 
    ultimately show "(x,t) \<in> (\<Union>e\<in>set ds. set (right_substs (fst e) (snd e)))"
      by force    
  qed
  show "?right \<subseteq> ?left" proof
    fix x t assume "(x,t) \<in> (\<Union>e\<in>set ds. set (right_substs (fst e) (snd e)))"
    then obtain j where j1:"j < length ss" and j2:"j < length ts" and "(x,t) \<in> set (right_substs (ss!j) (ts!j))" 
      unfolding ds by (metis (no_types, lifting) UN_E in_set_zip) 
    then obtain q where 1:"q \<in> fun_poss (ss!j)" and 2:"(ss!j)|_q = t" and 3:"q \<in> poss (ts!j)" and 4:"(ts!j)|_q = Var x"
      by (meson right_substs_imp_props)
    then have "j#q \<in> fun_poss (Fun f ss)" and "(Fun f ss)|_(j#q) = t" and "(j#q) \<in> poss (Fun g ts)" and "(Fun g ts)|_(j#q) = Var x" 
      using j1 j2 by auto
    then show "(x,t) \<in> set (right_substs (Fun f ss) (Fun g ts))"
      by (meson props_imp_right_substs)
  qed
qed 

lemma unify_linear_var_disjoint_terms:
  assumes "unify es substs = Some res"
      and "\<forall>t \<in> set (map fst es) \<union> set (map snd es). linear_term t"
      and "is_partition (set (map fst substs)#(map vars_term (map fst es))@(map vars_term (map snd es)))"
    shows "set res = set substs \<union> (\<Union>e \<in> set es. (set (left_substs (fst e) (snd e))) \<union> (set (right_substs (fst e) (snd e))))" 
  using assms proof(induct arbitrary: res substs rule:unify.induct)
  case (2 f ss g ts E)
  from 2(2) obtain ds where ds':"decompose (Fun f ss) (Fun g ts) = Some ds" 
    unfolding unify.simps by fastforce 
  then have ds:"ds = zip ss ts" and l:"length ss = length ts"
    by fastforce+
  with 2(3) have "\<forall>t \<in> set (map fst ds). linear_term t" 
    using map_fst_zip by (metis (no_types, lifting) UnCI fst_conv linear_term.simps(2) list.set_intros(1) list.simps(9))
  moreover from 2(3) ds l have "\<forall>t \<in> set (map snd ds). linear_term t" 
    using map_snd_zip by (metis (no_types, lifting) UnCI linear_term.simps(2) list.set_intros(1) list.simps(9) snd_conv) 
  moreover from ds' 2(2) have "unify (ds @ E) substs = Some res"
    by auto 
  moreover have "is_partition (set (map fst substs) # map vars_term (map fst (ds @ E)) @ map vars_term (map snd (ds @ E)))"
  proof-
    let ?xs="set (map fst substs) # map (vars_term \<circ> fst) E @ map (vars_term \<circ> snd) E"
    let ?ys="map vars_term ss @ map vars_term ts"
    from 2(4) have *:"is_partition (set (map fst substs) # [vars_term (Fun f ss)] @ map (vars_term \<circ> fst) E @ [vars_term (Fun g ts)] @ map (vars_term \<circ> snd) E)"
      by force
    then have "is_partition [vars_term (Fun f ss), vars_term (Fun g ts)]"
      by (metis append.simps is_partition_sublist) 
    then have disj:"vars_term (Fun f ss) \<inter> vars_term (Fun g ts) = {}"
      by (simp add: is_partition_Cons) 
    from * have 1:"is_partition ?xs" 
      using is_partition_sublist by (metis (no_types, opaque_lifting) append_Cons append_Nil append_Nil2) 
    have 2:"is_partition ?ys" proof-
      from 2(3) have "is_partition (map vars_term ss)" by simp 
      moreover from 2(3) have "is_partition (map vars_term ts)" by simp 
      moreover from disj have "\<forall>i<length ss. vars_term (ss ! i) \<inter> \<Union> (set (map vars_term ts)) = {}" 
        unfolding term.set(4) by fastforce
      ultimately show ?thesis 
        using is_partition_append by force
    qed
    have 3:"\<forall>i < length ?xs. ?xs!i \<inter> \<Union> (set ?ys) = {}" proof-
      {fix i assume "i < length ?xs"
      then consider "i=0" | "i > 0 \<and> i < Suc (length E)" | "i > length E \<and> i < Suc (length E + length E)"
        using not_less_eq by fastforce
      then have "?xs!i \<inter> \<Union> (set ?ys) = {}" proof(cases)
        case 1
        from * have "is_partition (set (map fst substs) # [vars_term (Fun f ss)] @ [vars_term (Fun g ts)])"
          by (metis append_Cons append_Nil is_partition_sublist) 
        then show ?thesis
          by (simp add: "1" is_partition_Cons)
      next
        case 2
        then have "?xs!i=(map (vars_term \<circ> fst) E @ map (vars_term \<circ> snd) E)!(i-1)"
          by simp
        with 2 obtain j where j:"j < length E" "?xs!i = (map (vars_term \<circ> fst) E) ! j"
          by (metis One_nat_def Suc_pred length_map not_less_eq nth_append) 
        from * have "is_partition (map (vars_term \<circ> fst) E @ [vars_term (Fun f ss)] @ [vars_term (Fun g ts)])"
          by (metis (no_types, opaque_lifting) append_Nil append_eq_appendI is_partition_Cons is_partition_reorder_list is_partition_sublist) 
        then have "\<forall>j < length E. vars_term (fst (E!j)) \<inter> \<Union> (set ?ys) = {}" 
          using is_partition_intersection by fastforce
        then show ?thesis unfolding j(2) using j(1) by simp
      next
        case 3
        then have "?xs!i=(map (vars_term \<circ> fst) E @ map (vars_term \<circ> snd) E)!(i-1)"
          by simp
        with 3 obtain j where j:"j < length E" "?xs!i = (map (vars_term \<circ> snd) E) ! j" 
          by (metis (no_types, lifting) One_nat_def Suc_eq_plus1_left add_diff_inverse_nat length_map less_Suc0 less_nat_zero_code nat_add_left_cancel_less not_less_eq nth_append)
        from * have "is_partition ([vars_term (Fun f ss)] @ [vars_term (Fun g ts)] @ map (vars_term \<circ> snd) E)"
          by (metis append.right_neutral append_Nil is_partition_Cons is_partition_sublist)
        then have "is_partition (map (vars_term \<circ> snd) E @ [vars_term (Fun f ss)] @ [vars_term (Fun g ts)])" 
          using is_partition_reorder_list by (metis append.assoc append.right_neutral same_append_eq) 
        then have "\<forall>j < length E. vars_term (snd (E!j)) \<inter> \<Union> (set ?ys) = {}" 
          using is_partition_intersection by fastforce
        then show ?thesis unfolding j(2) using j(1) by simp
      qed}
    then show ?thesis by simp
    qed
    have "is_partition (set (map fst substs) # map vars_term (map fst (ds @ E)) @ map vars_term (map snd (ds @ E))) =
          is_partition (set (map fst substs) # map vars_term ss @ map (vars_term \<circ> fst) E @ map vars_term ts @ map (vars_term \<circ> snd) E)"
      unfolding ds using l by simp 
    also have "... = is_partition (set (map fst substs) # map (vars_term \<circ> fst) E @ map vars_term ss @ map vars_term ts @ map (vars_term \<circ> snd) E)" 
      using is_partition_reorder_list by (metis append.simps) 
    also have " ... = is_partition (?xs@?ys)" 
      using is_partition_reorder_list by (metis (no_types, opaque_lifting) append_Cons append_Nil append_Nil2)  
    finally show ?thesis using 1 2 3
      using is_partition_append by blast
  qed
  ultimately have IH:"set res = set substs \<union> (\<Union>e\<in>set (ds @ E). set (left_substs (fst e) (snd e)) \<union> set (right_substs (fst e) (snd e)))"
    using ds' 2(3) 2(1)[where res=res]
    by (metis (no_types, lifting) Un_iff insert_is_Un list.map(2) list.simps(15) map_append set_append)
  moreover from ds' have "set (left_substs (Fun f ss) (Fun g ts)) = (\<Union>e\<in>set ds. set (left_substs (fst e) (snd e)))"
    by (simp add: decompose_left_substs)
  moreover from ds' have "set (right_substs (Fun f ss) (Fun g ts)) = (\<Union>e\<in>set ds. set (right_substs (fst e) (snd e)))"
    by (simp add: decompose_right_substs)
  ultimately show ?case by auto
next
  case (3 x t E)
  from 3(5) have part:"is_partition ({x} # map vars_term (map fst E) @ map vars_term (t#(map snd E)))" 
    unfolding list.map(2) fst_conv snd_conv term.set(3)
    by (metis append_Cons append_Nil is_partition_sublist append_Nil2)
  then have "\<forall>e \<in> set E. x \<notin> vars_term (fst e)"
    by (simp add: is_partition_Cons) 
  moreover from part have "\<forall>i < length E. x \<notin> vars_term (snd (E!i))" 
    by (simp add: is_partition_Cons) 
  ultimately have subst:"subst_list (subst x t) E = E"
    by (simp add: map_nth_eq_conv subst_list_def)
  from part have x:"x \<notin> vars_term t" 
    by (simp add: is_partition_Cons)
  then have x2:"t \<noteq> Var x"
    by fastforce 
  with 3(3) x have unif:"unify E ((x, t) # substs) = Some res"
    using unify.simps(3) subst by auto
  from 3(5) have "is_partition (set (map fst substs) # {x} # map vars_term (map fst E) @ map vars_term (map snd E))" 
    unfolding list.map(2) fst_conv snd_conv term.set(3)
    by (metis append_Cons append_Nil is_partition_sublist append_Nil2)
  then have "is_partition (set (map fst ((x, t) # substs)) # map vars_term (map fst E) @ map vars_term (map snd E))"
    unfolding list.map fst_conv  using is_partition_union insert_is_Un by force
  with x2 x unif 3(2,4) have IH:"set res = set ((x, t) # substs) \<union> (\<Union>e\<in>set E. set (left_substs (fst e) (snd e)) \<union> set (right_substs (fst e) (snd e)))"
    unfolding subst by auto
  have *:"filter (\<lambda>(_, p). p \<in> poss t) (zip (vars_term_list (Var x))(var_poss_list (Var x))) = [(x, [])]"
    by (simp add: poss_list.simps(1) vars_term_list.simps(1))  
  have left:"left_substs (Var x) t = [(x, t)]" 
    unfolding left_substs_def * by simp
  have **:"filter (\<lambda>(_, q). q \<in> fun_poss (Var x)) (zip (vars_term_list t) (var_poss_list t)) = []"
    by simp 
  then have right:"right_substs (Var x) t = []" 
    unfolding right_substs_def ** by simp
  then show ?case using right left IH by force 
next
  case (4 f ts x E)
  from 4(4) have "is_partition (map vars_term ((Fun f ts)#(map fst E)) @ ({x} # map vars_term (map snd E)))" 
    unfolding list.map(2) fst_conv snd_conv term.set(3)
    by (metis append_Cons append_Nil is_partition_sublist append_Nil2)
  then have part:"is_partition ({x} # map vars_term (Fun f ts # map fst E) @ map vars_term (map snd E))"
    using is_partition_reorder by blast 
  then have "\<forall>e \<in> set E. x \<notin> vars_term (fst e)" 
    by (simp add: is_partition_reorder is_partition_Cons) 
  moreover from part have "\<forall>i < length E. x \<notin> vars_term (snd (E!i))" 
    by (simp add: is_partition_Cons) 
  ultimately have subst:"subst_list (subst x (Fun f ts)) E = E"
    by (simp add: map_nth_eq_conv subst_list_def)
  from part have x:"x \<notin> vars_term (Fun f ts)" 
    by (simp add: is_partition_Cons)
  with 4(2) x have unif:"unify E ((x, Fun f ts) # substs) = Some res"
    using unify.simps(3) subst by auto
  from 4(4) have "is_partition ({x} # set (map fst substs) # map vars_term (map fst E) @  map vars_term (map snd E))" 
    unfolding list.map(2) fst_conv snd_conv term.set(3) 
    by (metis is_partition_reorder append_Cons append_Nil is_partition_sublist append_Nil2)
  then have "is_partition (set (map fst ((x, Fun f ts) # substs)) # map vars_term (map fst E) @ map vars_term (map snd E))"
    unfolding list.map fst_conv  using is_partition_union insert_is_Un by force
  with x unif 4(1,3) have IH:"set res = set ((x, Fun f ts) # substs) \<union> (\<Union>e\<in>set E. set (left_substs (fst e) (snd e)) \<union> set (right_substs (fst e) (snd e)))"
    unfolding subst by auto
  have "\<forall>p \<in> set (var_poss_list (Fun f ts)). p \<notin> {[]}" 
    unfolding var_poss_list_sound var_poss.simps by blast 
  then have "\<forall>(_, p) \<in> set (zip (vars_term_list (Fun f ts)) (var_poss_list (Fun f ts))). p \<notin> {[]}"
    using set_zip_rightD by fastforce
  then have *:"filter (\<lambda>(_, p). p \<in> poss (Var x)) (zip (vars_term_list (Fun f ts))(var_poss_list (Fun f ts))) = []"
    unfolding poss.simps using filter_False by (smt (z3) case_prodE case_prod_conv) 
  have left:"left_substs (Fun f ts) (Var x) = []" 
    unfolding left_substs_def * by simp
  have **:"filter (\<lambda>(_, q). q \<in> fun_poss (Fun f ts)) (zip (vars_term_list (Var x)) (var_poss_list (Var x))) = [(x,[])]"
    by (simp add: poss_list.simps(1) vars_term_list.simps(1)) 
  then have right:"right_substs (Fun f ts) (Var x) = [(x, Fun f ts)]" 
    unfolding right_substs_def ** by simp
  then show ?case using right left IH by force
qed auto

lemma mgu_linear_var_disjoint:
  assumes lin_s:"linear_term s" and lin_t:"linear_term t" 
    and unif:"unifiers {(s, t)} \<noteq> {}"
    and distinct:"distinct ((vars_term_list s) @ (vars_term_list t))"
  shows "mgu s t = Some (subst_of ((left_substs s t) @ (right_substs s t)))"
proof-
  let ?l_substs="left_substs s t"
  let ?r_substs="right_substs s t"
  have disj:"is_partition [vars_term s, vars_term t]"
    by (metis Sup_empty Sup_insert distinct distinct_append inf_bot_right is_partition_Cons is_partition_Nil list.set(1) list.set(2) set_vars_term_list sup_bot.right_neutral)
  from unif have "mgu s t \<noteq> None"
    by (meson mgu_complete) 
  then obtain us where "unify [(s, t)] [] = Some us" 
    unfolding mgu_def by fastforce
  moreover with lin_s lin_t disj have "set us = set ?l_substs \<union> set ?r_substs"
    using unify_linear_var_disjoint_terms[where substs="[]" and es="[(s, t)]" and res=us] is_partition_Cons
    by auto 
  moreover have "is_partition (map ((\<lambda>x. {x}) \<circ> fst) (?l_substs @ ?r_substs) @ (map (vars_term \<circ> snd) (?l_substs @ ?r_substs)))" proof-
    have part1:"is_partition (map ((\<lambda>x. {x}) \<circ> fst) (?l_substs @ ?r_substs))" proof-
      have part1:"is_partition (map ((\<lambda>x. {x}) \<circ> fst) ?l_substs)" 
        using lin_s distinct_map_fst_left_substs distinct_is_partition by fastforce 
      have part2:"is_partition (map ((\<lambda>x. {x}) \<circ> fst) ?r_substs)" 
        using lin_t distinct_map_fst_right_substs distinct_is_partition by fastforce 
      {fix i assume i:"i < length ?l_substs"
        then have "(map ((\<lambda>x. {x}) \<circ> fst) ?l_substs)!i \<subseteq> vars_term s" 
          using map_fst_left_substs by (smt (verit, best) length_map nth_map nth_mem o_apply singletonD subsetI subset_code(1))
        moreover have "\<Union> (set (map ((\<lambda>x. {x}) \<circ> fst) ?r_substs)) \<subseteq> vars_term t" 
          unfolding right_substs_def using zip_fst by fastforce
        ultimately have "(map ((\<lambda>x. {x}) \<circ> fst) ?l_substs)!i \<inter> \<Union> (set (map ((\<lambda>x. {x}) \<circ> fst) ?r_substs)) = {}"
          using distinct by (metis Int_mono distinct_append set_vars_term_list subset_empty) 
      }
      then show ?thesis using is_partition_append[OF part1 part2] by simp
    qed
    have part2:"is_partition (map (vars_term \<circ> snd) (?l_substs @ ?r_substs))" proof-
      have part1:"is_partition (map (vars_term \<circ> snd) ?l_substs)" 
        using lin_s lin_t is_partition_map_snd_left_substs by blast 
      have part2:"is_partition (map (vars_term \<circ> snd) ?r_substs)" 
        using lin_s lin_t is_partition_map_snd_right_substs by blast 
      {fix i assume i:"i < length ?l_substs"
        then have "(map (vars_term \<circ> snd) ?l_substs)!i \<subseteq> vars_term t" 
          using map_snd_left_substs using nth_mem by fastforce
        moreover have "\<Union> (set (map (vars_term \<circ> snd) ?r_substs)) \<subseteq> vars_term s" 
          using map_snd_right_substs by auto 
        ultimately have "(map (vars_term \<circ> snd) ?l_substs)!i \<inter> \<Union> (set (map (vars_term \<circ> snd) ?r_substs)) = {}"
          using distinct using set_vars_term_list subset_empty by fastforce
      }
      then show ?thesis using is_partition_append[OF part1 part2] by simp
    qed
    {fix i assume i:"i < length (?l_substs @ ?r_substs)" 
      then obtain x where x:"{x} = (map ((\<lambda>x. {x}) \<circ> fst) (?l_substs @ ?r_substs))!i"
        by (metis (no_types, lifting) nth_map o_apply)
      with i consider "x \<in> set (map fst ?l_substs)" | "x \<in> set (map fst ?r_substs)"
        by (smt (verit, best) Un_iff length_map map_append nth_map nth_mem o_apply set_append singleton_inject)
      then have "x \<notin> \<Union> (set (map (vars_term \<circ> snd) (?l_substs @ ?r_substs)))" proof(cases)
        case 1
        have "\<Union> (set (map (vars_term \<circ> snd) ?l_substs)) \<subseteq> vars_term t" 
          using map_snd_left_substs by auto
        moreover from 1 have "x \<in> vars_term s"
          unfolding left_substs_def using zip_fst by fastforce
        ultimately have "x \<notin> \<Union> (set (map (vars_term \<circ> snd) ?l_substs))"
          by (smt (verit, best) Union_upper disj disjoint_iff is_partition_Cons list.set_intros(1) subsetD) 
        moreover from 1 have "x \<notin> \<Union> (set (map (vars_term \<circ> snd) ?r_substs))" 
          using distinct_fst_lsubsts_snd_rsubsts[OF lin_s] by blast
        ultimately show ?thesis by simp
      next
        case 2
        have "\<Union> (set (map (vars_term \<circ> snd) ?r_substs)) \<subseteq> vars_term s" 
          using map_snd_right_substs by auto
        moreover from 2 have "x \<in> vars_term t"
          unfolding right_substs_def using zip_fst by fastforce
        ultimately have "x \<notin> \<Union> (set (map (vars_term \<circ> snd) ?r_substs))"
          by (smt (verit, best) Union_upper disj disjoint_iff is_partition_Cons list.set_intros(1) subsetD) 
        moreover from 2 have "x \<notin> \<Union> (set (map (vars_term \<circ> snd) ?l_substs))" 
          using distinct_fst_rsubsts_snd_lsubsts[OF lin_t] by blast
        ultimately show ?thesis by simp
      qed
      then have "(map ((\<lambda>x. {x}) \<circ> fst) (?l_substs @ ?r_substs))!i \<inter> \<Union> (set (map (vars_term \<circ> snd) (?l_substs @ ?r_substs))) = {}"
        unfolding x[symmetric] by blast
    }
    then show ?thesis using is_partition_append[OF part1 part2] by simp 
  qed
  ultimately show ?thesis
    unfolding mgu_def using subst_of_partition by (metis option.simps(5) set_append)
qed

end
