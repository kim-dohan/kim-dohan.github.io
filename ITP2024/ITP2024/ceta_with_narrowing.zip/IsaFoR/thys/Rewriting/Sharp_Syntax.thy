(*
Author:  Christian Sternagel <c.sternagel@gmail.com> (2015)
Author:  René Thiemann <rene.thiemann@uibk.ac.at> (2015)
License: LGPL (see file COPYING.LESSER)
*)

section \<open>Overloading for the Sharp Symbol\<close>

theory Sharp_Syntax
imports
  Main
  "HOL-Library.Adhoc_Overloading"
begin

consts SHARP :: "'a \<Rightarrow> 'b" ("\<sharp>")

locale sharp_syntax =
  fixes shp :: "'f \<Rightarrow> 'f"
begin

adhoc_overloading SHARP shp

end

end

